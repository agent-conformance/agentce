"""Command handlers for the AgentCE CLI (SPEC §8.5).

Each handler takes the parsed ``argparse.Namespace`` and returns a :class:`~agentce.result.CommandResult`.
Every command parses its arguments, validates its inputs (a missing or malformed input is an
``input_error``, exit code 3), emits ``--json`` output, and returns an exit code through the common
scheme. ``validate`` runs the ingest-and-validation stage (SPEC §8.1); ``version`` is fully
implemented; the remaining evaluation stages behind ``verify``, ``assess``, ``report``, ``collect``,
``catalog``, ``conformance``, ``diff``, and ``sign`` are layered on by the subsequent work items and
until then report ``status: not_implemented`` and exit ``ok``.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from collections.abc import Iterable
from contextlib import redirect_stdout
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any

import yaml

from .. import (
    ENGINE_NAME,
    SPEC_VERSION,
    __version__,
    bundled,
    i18n_format,
    messages,
    no_ml,
    readiness,
    signing,
    verdict,
)
from ..activity import summarize_activity
from ..applicability import resolve as resolve_applicability
from ..assertions import Assertion, aggregate
from ..assess import (
    apply_deviations,
    assess_subjects,
    deviations_by_control,
    evaluated_nothing,
)
from ..blind_spots import catalog_support_view, compute_blind_spots
from ..bundle import copy_bundle, load_bundle
from ..canonical import canonical_string, canonicalize
from ..catalog import Catalog, lint_catalog, load_catalog
from ..collect import EnvSecretManager, SourceSpec, load_config, run_collect
from ..config import resolve as resolve_config
from ..conformance import run_ecs
from ..coverage import compute_coverage
from ..coverage_matrix import MATRIX_FILE, check_matrix, write_matrix
from ..domain import DomainBinding
from ..environment import inspect_environment
from ..error_catalogue import MESSAGE_KEYS, render_errors_md
from ..errors import AgentceError, InputError
from ..exit_codes import ExitCode
from ..fail_on import parse_fail_on
from ..graph import build_graph
from ..ingest import ingest
from ..integrity import IntegrityStatus, verify_bundle
from ..logsetup import get_logger
from ..profile import Profile
from ..quarantine import counts_by_reason, write_quarantine
from ..records import (
    BUNDLE_DIR,
    DEFAULT_SUBJECT,
    DERIVED_PROFILE_FILE,
    RECORDS_LIMITATION,
    ScannedRecords,
)
from ..records import scan as scan_records
from ..report import (
    ASSESS_DEFAULT_EMIT,
    _package_digest,
    activity_cli_lines,
    applied_deviation_ids,
    blind_spots_cli_lines,
    has_invisible_codepoint,
    preset_cli_lines,
    render_evidence_pack,
    render_oscal,
    render_public_statement,
    render_report_html,
    render_report_md,
    render_sarif,
    sanitize_for_terminal,
    validate_report,
    write_report,
)
from ..result import CommandResult
from ..safe_yaml import load_untrusted_yaml
from ..state import StateDir, window_end
from ..store import GraphStore
from ..verdict import GAP_OUTCOMES

_log = get_logger()

REPORT_FORMATS = ("md", "html", "oscal", "sarif", "public", "pack")
#: Every token `assess --emit` accepts: the six `report --format` has always rendered one at a time,
#: plus report.py's newer renderers (SPEC §9). Kept identical to `report.EMIT_FORMATS`; a test holds
#: the two equal. `remediation` and `skill` are assess-only (Appendix A2 (C)) -- deliberately not in
#: `REPORT_FORMATS`, so `report --format` never accepts either.
EMIT_FORMATS = REPORT_FORMATS + (
    "junit",
    "csv",
    "oscal_xml",
    "pdf",
    "remediation",
    "skill",
)
#: The audience presets `assess --for` resolves to an `--emit` set (SPEC §13.4; contracts/P18-18.7.md).
#: Each preset is a fixed, hand-picked subset of :data:`EMIT_FORMATS` for one reader; it is sugar for
#: `--emit`, and a preset may also gate one additional, view-specific artifact set outside `--emit`
#: entirely (`security` gates `security.md`/`.html`/`.json`, 18.16) -- never a new rendering pipeline
#: for the formats :data:`EMIT_FORMATS` itself already names.
PRESET_EMIT: dict[str, frozenset[str]] = {
    "engineering": frozenset({"md", "html", "skill", "remediation"}),
    "compliance": frozenset({"oscal", "oscal_xml", "public", "pack", "csv"}),
    "security": frozenset({"sarif", "md", "html"}),
    "ci": frozenset({"sarif", "junit"}),
    "share": frozenset({"md", "html", "pdf", "public", "pack"}),
    #: Risk lead / CIO (18.14, Hill 7): the project view across every agent, side by side --
    #: `md`/`html` render `project.*`/`agents/<dirname>/*` whenever `--profile` declares more than
    #: one subject, the same two formats `security` already renders.
    "risk-lead": frozenset({"md", "html"}),
    #: Auditor (18.17): the compliance preset's core (`oscal`/`oscal_xml`/`pack`, minus `public`/`csv`,
    #: which the auditor view's own OSCAL/evidence-bundle pointer section already covers). `md`/`html`
    #: are deliberately absent -- unlike `security`, `auditor.md`/`.html` are always written for this
    #: preset (the `security.json`/`auditor.json` "always written" idiom, extended to `.md`/`.html`
    #: too), never gated by the shared `md`/`html` emit tokens, which would also write the unrelated
    #: ordinary `report.md`/`.html` (altitude review, contracts/P18-18.17.md C3's own file-set).
    "auditor": frozenset({"oscal", "oscal_xml", "pack"}),
    #: Buyer (18.18): generated questionnaire answers (CAIQ / the AI Controls Matrix), a one-page
    #: summary, and how to check this report. `md`/`html` are always written for this preset, the
    #: same `auditor.json`/`.md`/`.html` "always written" idiom `auditor` above already uses -- one
    #: evidence pack per subject (`pack`) is the "how to check this report" artifact beyond the
    #: view's own rendered pages; no `oscal`/`oscal_xml` (auditor's territory).
    "buyer": frozenset({"pack"}),
}
#: `CI` values treated as "not in CI" (the `ci-info` convention): unset, empty, or one of these,
#: case-insensitively. Jenkins (`JENKINS_URL`/`BUILD_ID`) and Azure Pipelines (`TF_BUILD`) are not
#: detected by this check and get no automatic `junit` -- a known, disclosed gap (contracts/P18-18.7.md
#: D6), not a silent regression: those environments simply keep today's legacy default.
_CI_FALSY = frozenset({"", "0", "false", "no", "off"})


def _ci_detected() -> bool:
    """Whether the `CI` environment variable names a CI run (GitHub Actions, GitLab CI, CircleCI,
    Travis, Buildkite, and Bitbucket Pipelines all set `CI=true` by default)."""
    return os.environ.get("CI", "").strip().lower() not in _CI_FALSY


#: Where a command writes, or reads a project from, when the caller names no directory: the working
#: directory for a project (``init``, ``doctor``) and ``./out`` for a run's output (``assess``,
#: ``quickstart``), so the first command a newcomer types needs no flag.
DEFAULT_PROJECT_DIR = "."
DEFAULT_OUT_DIR = "out"
SIGN_ROLES = ("claimant", "assessor")
SIGN_PROFILES = ("sigstore-public", "sigstore-private", "kms")


def _opt_str(ns: argparse.Namespace, name: str) -> str | None:
    value = getattr(ns, name, None)
    return None if value is None else str(value)


def _flag(ns: argparse.Namespace, name: str) -> bool:
    return bool(getattr(ns, name, False))


def _require_dir(
    raw: str | None, *, key: str, what: str, fix: str | None = None
) -> Path:
    fix = fix or f"pass --{key.replace('_', '-')} <dir>."
    if raw is None:
        raise InputError(f"input.{key}_missing", f"{what} is required.", fix)
    path = Path(raw)
    if not path.is_dir():
        raise InputError(
            f"input.{key}_not_a_directory",
            f"{what} {raw!r} is not an existing directory.",
            fix,
        )
    return path


def _require_file(
    raw: str | None, *, key: str, what: str, fix: str | None = None
) -> Path:
    fix = fix or f"pass --{key.replace('_', '-')} <file>."
    if raw is None:
        raise InputError(f"input.{key}_missing", f"{what} is required.", fix)
    path = Path(raw)
    if not path.is_file():
        raise InputError(
            f"input.{key}_not_a_file",
            f"{what} {raw!r} is not an existing file.",
            fix,
        )
    return path


def _write_jsonl(records: Iterable[dict[str, Any]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, sort_keys=True, separators=(",", ":")))
            handle.write("\n")


def cmd_validate(ns: argparse.Namespace) -> CommandResult:
    result = CommandResult(command="validate")
    bundle_dir = _require_dir(
        _opt_str(ns, "bundle"), key="bundle", what="the evidence bundle"
    )
    bundle = load_bundle(
        bundle_dir
    )  # raises InputError (exit 3) on a missing/mismatching manifest
    ingested = ingest(bundle)
    result.data.update(
        {
            "bundle": str(bundle_dir),
            "bundle_digest": bundle.digest,
            "accepted": len(ingested.accepted),
            "quarantined": len(ingested.quarantined),
            "quarantine_by_reason": counts_by_reason(ingested.quarantined),
        }
    )
    out = _opt_str(ns, "out")
    if out is not None:
        quarantine_path = Path(out) / "quarantine.jsonl"
        write_quarantine(ingested.quarantined, quarantine_path)
        result.data["quarantine_file"] = str(quarantine_path)
    result.note(
        f"validated {bundle_dir}: {len(ingested.accepted)} accepted, "
        f"{len(ingested.quarantined)} quarantined"
    )
    if ingested.quarantined:
        result.add_code(int(ExitCode.FINDINGS))
    return result


def cmd_verify(ns: argparse.Namespace) -> CommandResult:
    result = CommandResult(command="verify")
    bundle = _opt_str(ns, "bundle")
    catalog = _opt_str(ns, "catalog")
    release = _opt_str(ns, "release")
    report = _opt_str(ns, "report")
    chosen = [
        name
        for name, value in (
            ("bundle", bundle),
            ("catalog", catalog),
            ("release", release),
            ("report", report),
        )
        if value
    ]
    if len(chosen) != 1:
        raise InputError(
            "input.verify_target",
            "verify needs exactly one of --bundle, --catalog, --release, or --report.",
            "pass exactly one target, e.g. `agentce verify --bundle <dir>`.",
        )
    signer_trust_root = _opt_str(ns, "signer_trust_root")
    expect_keyid = _opt_str(ns, "expect_keyid")
    if report is None and (signer_trust_root is not None or expect_keyid is not None):
        raise InputError(
            "input.verify_target",
            "--signer-trust-root/--expect-keyid apply only to --report.",
            "pass --report <dir> together with --signer-trust-root/--expect-keyid, or drop them.",
        )
    if bundle is not None:
        bundle_dir = _require_dir(bundle, key="bundle", what="the evidence bundle")
        loaded = load_bundle(bundle_dir)
        ingested = ingest(loaded)
        results = verify_bundle(ingested.accepted, loaded.manifest, loaded.root)
        clean = {IntegrityStatus.VERIFIED.value, IntegrityStatus.VERIFIED_WEAK.value}
        broken = [r for r in results if r.status not in clean]
        result.data.update(
            {
                "bundle": str(bundle_dir),
                "streams": [r.to_json() for r in results],
                "stream_count": len(results),
                "broken_streams": len(broken),
            }
        )
        result.note(
            f"verified {bundle_dir}: {len(results)} streams, {len(broken)} broken"
        )
        if broken:
            result.add_code(int(ExitCode.FINDINGS))
        return result
    if catalog is not None:
        catalog_dir = _require_dir(catalog, key="catalog", what="the catalog directory")
        return _verify_catalog(result, catalog_dir)
    if report is not None:
        report_dir = _require_dir(report, key="report", what="the report directory")
        return _verify_report(result, report_dir, signer_trust_root, expect_keyid)
    release_path = Path(release)  # type: ignore[arg-type]
    if not release_path.exists():
        raise InputError(
            "input.release_missing",
            f"the release artifact {release!r} does not exist.",
            "pass --release <bundle-dir-or-envelope>.",
        )
    return _verify_release(result, release_path)


def _verify_catalog(result: CommandResult, catalog_dir: Path) -> CommandResult:
    """Verify a catalog directory's signature offline against the vendored trust root (SPEC §8.7)."""
    recomputed = signing.digest_tree(
        catalog_dir, exclude=frozenset({signing.CATALOG_SIGNATURE_NAME})
    )
    result.data.update({"catalog": str(catalog_dir), "digest": recomputed})
    try:
        verified = signing.verify_catalog_directory(
            catalog_dir, signing.vendored_trust()
        )
    except signing.UnsignedError as exc:
        result.data["verified"] = False
        result.data["reason"] = str(exc)
        result.note(f"catalog {catalog_dir.name}: unsigned")
        result.add_code(int(ExitCode.INPUT_ERROR))
        return result
    except (signing.VerificationError, ValueError, KeyError, IndexError) as exc:
        result.data["verified"] = False
        result.data["reason"] = str(exc)
        result.note(f"catalog {catalog_dir.name}: verification failed — {exc}")
        result.add_code(int(ExitCode.INPUT_ERROR))
        return result
    result.data.update(
        {
            "verified": True,
            "signer": verified.identity,
            "keyid": verified.keyid,
            "keyless": verified.keyless,
        }
    )
    result.note(f"verified catalog {catalog_dir.name}: signer {verified.identity}")
    return result


#: The subjects `agentce sign` always covers (`_sign_subjects`): a `verify --report` re-run treats
#: an omitted one as itself a failure, never a silently-skipped check (SPEC 18.8, Hill 3).
REQUIRED_REPORT_SUBJECTS = ("manifest.json", "claim.json")
#: The deterministic per-run artifacts a `verify --report` re-run byte-compares against the shipped
#: ones -- never a rendered format (the re-run passes `--emit ""`, so none exist to compare).
_RERUN_COMPARE_FILES = (
    "assertions.json",
    "activity.json",
    "blind-spots.json",
    "coverage.json",
    "integrity.jsonl",
    "applicability.jsonl",
)


def _load_report_trust_root(path: Path) -> signing.TrustRoot:
    """Load a `verify --report` trust root (external `--signer-trust-root` or an embedded
    `trust-root.json`), reusing `input.trust_root_invalid` -- the same key `--trust-root`/
    `AGENTCE_TRUST_ROOT` already use for an unreadable or malformed file, including one
    `TrustRoot.from_dict`'s own keyid invariant refuses as forged (signing.py)."""
    if not path.is_file():
        raise InputError(
            "input.trust_root_invalid",
            f"the trust root {str(path)!r} does not exist.",
            "pass --signer-trust-root <file>, or ask the sender to re-sign with "
            "`sign --write-trust-root`.",
        )
    try:
        return signing.load_trust_root(path)
    except signing.VerificationError as exc:
        raise InputError(
            "input.trust_root_invalid",
            f"the trust root {str(path)!r} could not be loaded: {exc}",
            "pass a trust root file shaped like the one `sign --write-trust-root` writes.",
        ) from exc


def _verify_report(
    result: CommandResult,
    report_dir: Path,
    trust_root_path: str | None,
    expect_keyid: str | None,
) -> CommandResult:
    """Re-run a shareable report bundle (`assess --package-for-sharing`) offline, byte-compare the
    canonical outputs against the shipped ones, and refuse any tampering (SPEC 18.8, Hill 3;
    contracts/P18-18.8.md C3). Nine stages, each with its own message key, in order: (1) the claim
    exists and is signed, (2) the trust root resolves, (3) a claimant signature verifies, (4) the
    signed subjects (manifest.json, claim.json) match what's on disk, (5) the engine build matches,
    (6) every manifest-tracked output's digest matches, (7) the packaged evidence/profile/domain/
    catalogs match, (8) an offline re-run reproduces every canonical output byte for byte, (9)
    success."""
    claim_path = report_dir / "claim.json"
    if not claim_path.is_file():
        raise InputError(
            "verify.report_no_claim",
            f"{report_dir} has no claim.json.",
            "pass the directory `agentce assess` wrote and `agentce sign` signed.",
        )
    try:
        claim = json.loads(claim_path.read_text("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise InputError(
            "verify.report_claim_malformed",
            f"claim.json is not valid JSON: {exc}.",
            "regenerate the report; claim.json must be well-formed JSON.",
        ) from exc
    signatures = claim.get("signatures") or []
    if not signatures:
        raise InputError(
            "verify.report_unsigned",
            "claim.json carries no signatures.",
            "sign the report first: `agentce sign <report-dir> --as claimant`.",
        )

    if trust_root_path is not None:
        trust_source = "external"
        trust = _load_report_trust_root(Path(trust_root_path))
    else:
        embedded_path = report_dir / "trust-root.json"
        if not embedded_path.is_file():
            raise InputError(
                "verify.report_no_trust_root",
                f"{report_dir} has no embedded trust-root.json, and --signer-trust-root was not given.",
                "pass --signer-trust-root <file>, or ask the sender to re-sign with "
                "`sign --write-trust-root`.",
            )
        trust_source = "embedded"
        trust = _load_report_trust_root(embedded_path)

    candidates = [s for s in signatures if s.get("role") == "claimant"]
    if expect_keyid is not None:
        candidates = [
            s
            for s in candidates
            if any(sig.get("keyid") == expect_keyid for sig in s.get("signatures", []))
        ]
        if not candidates:
            raise InputError(
                "verify.report_keyid_mismatch",
                f"no claimant signature has keyid {expect_keyid!r}.",
                "confirm the keyid with the sender, or drop --expect-keyid.",
            )
    verified = None
    verified_statement: dict[str, Any] = {}
    last_error: Exception | None = None
    for candidate in candidates:
        try:
            v = signing.verify_envelope(candidate, trust)
            statement = json.loads(v.payload)
        except (
            signing.VerificationError,
            json.JSONDecodeError,
            UnicodeDecodeError,
        ) as exc:
            last_error = exc
            continue
        if statement.get("predicate", {}).get("role") != "claimant":
            last_error = signing.VerificationError(
                "the verified predicate's own role is not 'claimant'"
            )
            continue
        verified = v
        verified_statement = statement
        break
    if verified is None:
        raise InputError(
            "verify.report_signature_invalid",
            f"no claimant signature verified against the trust root: {last_error}.",
            "confirm the trust root holds the signer's real key, or re-sign the report.",
        )
    assert (
        verified.keyid is not None
    )  # every DSSE signature `sign_statement` writes carries one
    if trust_source == "embedded":
        print(
            f"warning: this key came from inside the bundle; confirm keyid {verified.keyid} "
            "with the sender for full assurance.",
            file=sys.stderr,
        )

    subject_map = {s["name"]: s for s in verified_statement.get("subject", [])}
    for name in REQUIRED_REPORT_SUBJECTS:
        if name not in subject_map:
            raise InputError(
                "verify.report_subject_missing",
                f"the signed statement has no subject named {name!r}.",
                "re-sign the report: `agentce sign <report-dir> --as claimant`.",
            )
    manifest_path = report_dir / "manifest.json"
    if not manifest_path.is_file():
        raise InputError(
            "verify.report_output_tampered",
            f"{report_dir} has no manifest.json.",
            "regenerate the report with `agentce assess`.",
        )
    manifest_bytes = manifest_path.read_bytes()
    if (
        hashlib.sha256(manifest_bytes).hexdigest()
        != subject_map["manifest.json"]["digest"]["sha256"]
    ):
        raise InputError(
            "verify.report_manifest_tampered",
            "manifest.json does not match the digest the signature covers.",
            "the manifest was altered after signing; regenerate and re-sign the report.",
        )
    manifest = json.loads(manifest_bytes.decode("utf-8"))
    claim_body = {k: v for k, v in claim.items() if k != "signatures"}
    if (
        hashlib.sha256(canonicalize(claim_body)).hexdigest()
        != subject_map["claim.json"]["digest"]["sha256"]
    ):
        raise InputError(
            "verify.report_claim_tampered",
            "claim.json does not match the digest the signature covers.",
            "the claim was altered after signing; regenerate and re-sign the report.",
        )

    engine = manifest.get("engine", {})
    installed = {
        "version": __version__,
        "spec_version": SPEC_VERSION,
        "package_digest": _package_digest(),
    }
    if any(engine.get(k) != v for k, v in installed.items()):
        raise InputError(
            "verify.report_engine_mismatch",
            f"this report was produced by engine {engine.get('version')!r} "
            f"(spec {engine.get('spec_version')!r}); this machine has a different build.",
            f"install engine {engine.get('version')!r} (spec {engine.get('spec_version')!r}) "
            "to re-run this report.",
        )

    tampered: list[str] = []
    for name, expected in manifest.get("outputs", {}).items():
        candidate_path = report_dir / name
        if not candidate_path.is_file():
            tampered.append(name)
            continue
        actual = signing.sha256_prefixed(candidate_path.read_bytes())
        if actual != expected:
            tampered.append(name)
    if tampered:
        raise InputError(
            "verify.report_output_tampered",
            f"these manifest-tracked outputs are missing or altered: {', '.join(sorted(tampered))}.",
            "the report was altered after signing; regenerate and re-sign it.",
        )

    packaging = json.loads((report_dir / "packaging.json").read_text("utf-8"))
    if not packaging.get("packaged"):
        result.data.update(
            {
                "reproduced": None,
                "reason": "this report was not packaged for re-running",
            }
        )
        result.note(f"{report_dir}: not packaged for re-running (nothing to reproduce)")
        return result

    inputs = manifest.get("inputs", {})
    bundle_evidence = report_dir / "bundle" / "evidence"
    try:
        loaded_bundle = load_bundle(bundle_evidence)
    except InputError as exc:
        raise InputError(
            "verify.report_evidence_tampered",
            f"bundle/evidence does not load cleanly: {exc.cause}",
            "the packaged evidence was altered after signing; regenerate and re-sign the report.",
        ) from exc
    if loaded_bundle.digest != inputs.get("bundle_digest"):
        raise InputError(
            "verify.report_evidence_tampered",
            "bundle/evidence's digest does not match manifest.json's bundle_digest.",
            "the packaged evidence was altered after signing; regenerate and re-sign the report.",
        )
    profile_path = report_dir / "bundle" / "applicability.yaml"
    if not profile_path.is_file() or signing.sha256_prefixed(
        profile_path.read_bytes()
    ) != inputs.get("applicability_profile_digest"):
        raise InputError(
            "verify.report_evidence_tampered",
            "bundle/applicability.yaml is missing or does not match its recorded digest.",
            "the packaged profile was altered after signing; regenerate and re-sign the report.",
        )
    domain_digest = inputs.get("domain_binding_digest")
    domain_path = report_dir / "bundle" / "domain.linkml.yaml"
    if domain_digest is not None:
        if (
            not domain_path.is_file()
            or signing.sha256_prefixed(domain_path.read_bytes()) != domain_digest
        ):
            raise InputError(
                "verify.report_evidence_tampered",
                "bundle/domain.linkml.yaml is missing or does not match its recorded digest.",
                "the packaged domain binding was altered after signing; regenerate and re-sign "
                "the report.",
            )
    deviation_digest = inputs.get("deviation_register_digest")
    deviations_path = report_dir / "bundle" / "deviations.yaml"
    if deviation_digest is not None:
        if (
            not deviations_path.is_file()
            or signing.sha256_prefixed(deviations_path.read_bytes()) != deviation_digest
        ):
            raise InputError(
                "verify.report_evidence_tampered",
                "bundle/deviations.yaml is missing or does not match its recorded digest.",
                "the packaged deviation register was altered after signing; regenerate and "
                "re-sign the report.",
            )
    catalog_dir_order = packaging.get("catalog_dir_order", [])
    catalog_dir_digests = packaging.get("catalog_dir_digests", {})
    for position, label in enumerate(catalog_dir_order):
        catalog_path = report_dir / "bundle" / "catalog" / str(position)
        if not catalog_path.is_dir() or signing.digest_tree(
            catalog_path
        ) != catalog_dir_digests.get(label):
            raise InputError(
                "verify.report_evidence_tampered",
                f"bundle/catalog/{position} ({label}) is missing or does not match its "
                "recorded digest.",
                "the packaged catalog was altered after signing; regenerate and re-sign the "
                "report.",
            )

    # Step 8: the offline re-run. A scratch trust root built from THIS report's own verified
    # signer key (never the recipient's ambient --trust-root/AGENTCE_TRUST_ROOT) is what any
    # --catalog-dir re-run trusts, so the check depends solely on what the sender's signature
    # covers, identical on every recipient machine regardless of local trust configuration.
    allow_unverified = any(
        "--allow-unverified-catalog" in lim for lim in manifest.get("limitations", [])
    )
    catalog_positions = {label: i for i, label in enumerate(catalog_dir_order)}
    vendored_labels: list[str] = []
    catalog_dir_args: list[str] = []
    for ref in inputs.get("catalogs", []):
        label = f"{ref['id']}@{ref['version']}"
        dir_position = catalog_positions.get(label)
        if dir_position is not None:
            catalog_dir_args += [
                "--catalog-dir",
                str(report_dir / "bundle" / "catalog" / str(dir_position)),
            ]
        else:
            vendored_labels.append(label)

    with tempfile.TemporaryDirectory(prefix="agentce-verify-report-") as scratch_raw:
        scratch = Path(scratch_raw)
        argv = [
            "assess",
            "--bundle",
            str(bundle_evidence),
            "--profile",
            str(profile_path),
        ]
        if domain_digest is not None:
            argv += ["--domain", str(domain_path)]
        if deviation_digest is not None:
            argv += ["--deviations", str(deviations_path)]
        if vendored_labels:
            argv += ["--catalog", ",".join(vendored_labels)]
        argv += catalog_dir_args
        if catalog_dir_args:
            scratch_trust_path = scratch / "trust-root.json"
            scratch_trust_path.write_text(
                json.dumps(
                    signing.TrustRoot.document(
                        verified.keyid,
                        signing.public_ed25519_b64(trust.keys[verified.keyid]),
                        verified.identity,
                    )
                ),
                encoding="utf-8",
            )
            argv += ["--trust-root", str(scratch_trust_path)]
        if allow_unverified:
            argv.append("--allow-unverified-catalog")
        argv += ["--emit", "", "--out", str(scratch / "out"), "--quiet"]

        from .. import cli as _cli  # deferred: cli imports this module at top level

        saved_step_summary = os.environ.pop("GITHUB_STEP_SUMMARY", None)
        try:
            # The re-run's own report text has no reader here -- only its files matter, compared
            # below -- so its stdout (`--quiet` silences only logging, not the result rendering
            # `main` always does) is captured and discarded rather than mixed into this command's
            # own output.
            with redirect_stdout(io.StringIO()):
                _cli.main(
                    argv
                )  # an ordinary assess outcome (0/1/2) is not itself a failure here
        finally:
            if saved_step_summary is not None:
                os.environ["GITHUB_STEP_SUMMARY"] = saved_step_summary

        mismatched_files: list[str] = []
        for name in _RERUN_COMPARE_FILES:
            shipped = report_dir / name
            produced = scratch / "out" / name
            if not produced.is_file() or not shipped.is_file():
                mismatched_files.append(name)
                continue
            if produced.read_bytes() != shipped.read_bytes():
                mismatched_files.append(name)
        if mismatched_files:
            raise InputError(
                "verify.report_reproduction_mismatch",
                f"the re-run does not reproduce {mismatched_files[0]!r} byte for byte "
                f"({len(mismatched_files)} file(s) differ).",
                "run `agentce diff` between the shipped and re-run outputs for the full picture.",
            )

    result.data.update(
        {
            "reproduced": True,
            "signer": verified.identity,
            "keyid": verified.keyid,
            "trust_source": trust_source,
            "files_checked": len(manifest.get("outputs", {}))
            + len(REQUIRED_REPORT_SUBJECTS),
        }
    )
    note = f"{report_dir}: reproduced, signer {verified.identity}"
    if trust_source == "embedded":
        note += " (embedded trust-root.json -- confirm the keyid with the sender out of band)"
    result.note(note)
    return result


def _verify_release(result: CommandResult, release_path: Path) -> CommandResult:
    """Verify a release bundle (or a single DSSE envelope) offline against the vendored trust root."""
    trust = signing.vendored_trust()
    if release_path.is_file():
        envelope = json.loads(release_path.read_text("utf-8"))
        verified = signing.verify_envelope(envelope, trust)
        result.data.update(
            {
                "release": str(release_path),
                "verified": True,
                "signer": verified.identity,
                "keyid": verified.keyid,
            }
        )
        result.note(f"verified {release_path.name}: signer {verified.identity}")
        return result
    manifest_path = release_path / "release-manifest.json"
    signatures_path = release_path / "signatures.json"
    if not manifest_path.is_file() or not signatures_path.is_file():
        raise InputError(
            "input.release_bundle",
            f"{release_path} is not a release bundle (release-manifest.json/signatures.json).",
            "pass the --out directory produced by the release tooling.",
        )
    manifest = json.loads(manifest_path.read_text("utf-8"))
    manifest_digest = signing.sha256_prefixed(canonicalize(manifest))
    problems: list[str] = []
    for artifact in manifest.get("artifacts", []):
        artifact_file = release_path / artifact["name"]
        if not artifact_file.is_file():
            problems.append(f"missing artifact {artifact['name']}")
            continue
        actual = signing.sha256_prefixed(artifact_file.read_bytes())
        if actual != artifact.get("digest"):
            problems.append(f"digest mismatch for {artifact['name']}")
    signers: list[dict[str, Any]] = []
    for entry in json.loads(signatures_path.read_text("utf-8")):
        try:
            verified = signing.verify_envelope(entry["envelope"], trust)
            if (
                signing.statement_subject_digest(json.loads(verified.payload))
                != manifest_digest
            ):
                raise signing.VerificationError(
                    "signature does not cover the release manifest"
                )
            signers.append(
                {"profile": entry.get("profile"), "identity": verified.identity}
            )
        except (signing.VerificationError, ValueError, KeyError) as exc:
            problems.append(f"signature ({entry.get('profile')}): {exc}")
    ok = not problems
    result.data.update(
        {
            "release": str(release_path),
            "verified": ok,
            "manifest_digest": manifest_digest,
            "signers": signers,
        }
    )
    if not ok:
        result.data["reason"] = "; ".join(problems)
        result.note(f"release {release_path.name}: verification failed")
        result.add_code(int(ExitCode.INPUT_ERROR))
    else:
        result.note(f"verified release {release_path.name}: {len(signers)} signatures")
    return result


def _parse_emit(raw: str | None) -> frozenset[str] | None:
    """Parse and validate ``--emit``'s comma-separated token list (SPEC §9). ``None`` when the flag
    is absent, so ``cmd_assess`` resolves its own default (:data:`agentce.report.ASSESS_DEFAULT_EMIT`).
    Every token is validated here, before any output is written: an assessment that names a format it
    cannot produce must leave nothing behind that looks like a result (mirrors ``cmd_report``'s
    ``input.report_format`` check for the single-format ``--format`` flag)."""
    if raw is None:
        return None
    tokens = [t.strip() for t in raw.split(",") if t.strip()]
    invalid = [t for t in tokens if t not in EMIT_FORMATS]
    if invalid:
        raise InputError(
            "input.emit_format",
            f"unknown --emit format(s): {', '.join(repr(t) for t in invalid)}.",
            f"choose from: {', '.join(EMIT_FORMATS)}.",
        )
    return frozenset(tokens)


def _resolve_emit(
    ns: argparse.Namespace,
) -> tuple[frozenset[str], str | None, str | None]:
    """Resolve `--emit`/`--for`/CI auto-detection into one final format set, validated before any
    output is written (same invariant as :func:`_parse_emit`): a bad flag combination or an unknown
    preset must never leave a partial or misleading result behind (contracts/P18-18.7.md). Returns
    ``(formats, preset, preset_source)`` -- ``preset`` is the ``--for`` value or ``None``;
    ``preset_source`` is ``"flag"``, ``"ci-env"``, or ``None`` when neither resolved anything, in
    which case ``formats`` is the caller's explicit ``--emit`` set or ``assess``'s own default
    (unlike ``write_report``'s frozen ``emit=None`` bundle, SPEC's evidence-first framing, RFC 0008
    Sec.8: the skill is emitted by every default run of the command a user actually runs; an explicit
    ``--emit`` still names exactly what it names)."""
    emit_raw = _opt_str(ns, "emit")
    emit = _parse_emit(emit_raw)
    for_preset = _opt_str(ns, "for_preset")
    if for_preset is not None and emit_raw is not None:
        raise InputError(
            "input.for_emit_ambiguous",
            "both --for and --emit were given.",
            "pass --for <preset> or --emit <formats>, not both.",
        )
    if for_preset is not None and for_preset not in PRESET_EMIT:
        raise InputError(
            "input.for_preset",
            f"unknown --for preset {for_preset!r}.",
            f"choose one of: {', '.join(PRESET_EMIT)}.",
        )
    if for_preset is not None:
        return PRESET_EMIT[for_preset], for_preset, "flag"
    if emit is None and _ci_detected():
        return ASSESS_DEFAULT_EMIT | {"junit"}, None, "ci-env"
    return (emit if emit is not None else ASSESS_DEFAULT_EMIT), None, None


def cmd_assess(ns: argparse.Namespace) -> CommandResult:
    result = CommandResult(command="assess")
    out = _opt_str(ns, "out") or DEFAULT_OUT_DIR
    folder_arg = _opt_str(ns, "folder")
    scanned: ScannedRecords | None = None
    derived_profile = False
    if folder_arg is None:
        bundle = _require_dir(
            _opt_str(ns, "bundle"), key="bundle", what="the evidence bundle"
        )
        profile = _require_file(
            _opt_str(ns, "profile"), key="profile", what="the applicability profile"
        )
        profile_obj = Profile.load(profile)
    else:
        # A records folder is read in memory first; nothing is written until the run is known to be
        # well-formed (below), so a refused run leaves nothing behind that looks like a result.
        if _opt_str(ns, "bundle") is not None:
            raise InputError(
                "input.records_source_ambiguous",
                "both a records folder and --bundle were given.",
                "pass either a folder of trace exports or --bundle <dir>, not both.",
            )
        folder = _require_dir(
            folder_arg,
            key="records",
            what="the records folder",
            fix="pass a folder of OpenTelemetry GenAI or OpenInference trace exports.",
        )
        profile_arg = _opt_str(ns, "profile")
        declared: Profile | None = None
        if profile_arg is not None:
            profile = _require_file(
                profile_arg, key="profile", what="the applicability profile"
            )
            declared = Profile.load(profile)
        else:
            profile = Path(out) / DERIVED_PROFILE_FILE
        scanned = scan_records(
            folder, subject=_records_subject(declared), exclude=Path(out)
        )
        derived_profile = declared is None
        profile_obj = declared or Profile.from_dict(scanned.profile)
        bundle = Path(out) / BUNDLE_DIR
    catalog = _opt_str(ns, "catalog")
    # --package-for-sharing (18.8, Hill 3): a records-folder run's evaluation mode
    # (`applicability_declared=False`, below) makes a `--bundle`-shaped re-run not reproduce it, so
    # packaging is refused outright for that form, before anything is written.
    package_for_sharing = _flag(ns, "package_for_sharing")
    if package_for_sharing and folder_arg is not None:
        raise InputError(
            "input.package_requires_bundle",
            "--package-for-sharing works only with --bundle/--profile, not a records folder.",
            "pass --bundle and --profile instead of a records folder, or drop --package-for-sharing.",
        )
    # --emit/--for/CI-detection are all resolved and validated before any output is written (below,
    # before ingest/quarantine): an unknown token, a bad flag combination, or an unknown preset must
    # never leave a partial or misleading result behind.
    resolved_emit, for_preset, preset_source = _resolve_emit(ns)
    # --fail-on is parsed (never eval'd) before any output is written too: a hostile or malformed
    # expression is refused at exit 3 before any assertion is evaluated against it (SPEC §7).
    fail_on_raw = _opt_str(ns, "fail_on")
    fail_on_predicate = parse_fail_on(fail_on_raw) if fail_on_raw is not None else None
    # Resolve the catalogs before any output is written: a run that cannot name what it evaluates
    # against — or cannot verify it — must leave nothing behind that looks like a result.
    raw_catalog_dirs = list(getattr(ns, "catalog_dir", None) or [])
    catalogs, catalog_labels, limitations = _resolve_catalogs(
        catalog,
        profile_obj,
        raw_catalog_dirs,
        _effective_trust_root(ns),
        allow_unverified=_flag(ns, "allow_unverified_catalog"),
    )
    out_dir = Path(out)
    domain_path_early = _opt_str(ns, "domain")
    deviations_path = _opt_str(ns, "deviations")
    if package_for_sharing:
        _check_package_path_overlap(
            out_dir,
            bundle,
            profile,
            domain_path_early,
            raw_catalog_dirs,
            deviations_path,
        )
    if scanned is not None:
        scanned.write(out_dir, write_profile=derived_profile)
        limitations.append(RECORDS_LIMITATION)
    # Stage 1: ingest and validate. A missing/mismatching manifest aborts with exit 3.
    loaded = load_bundle(bundle)
    ingested = ingest(loaded)
    write_quarantine(ingested.quarantined, out_dir / "quarantine.jsonl")
    # Packaging for sharing (18.8, Hill 3), right after Stage 1 so the copy reflects exactly what was
    # ingested: --out becomes self-contained, ready for `agentce verify --report` to re-run offline.
    # `catalog_dir_order`/`catalog_dir_digests` are recorded in `packaging.json` below (never as new
    # `manifest.json` `inputs` properties, which the schema does not declare) so no schema change is
    # needed; keyed/indexed to avoid a directory-name collision between two `--catalog-dir`s.
    catalog_dir_order: list[str] = []
    catalog_dir_digests: dict[str, str] = {}
    if package_for_sharing:
        bundle_out = out_dir / "bundle"
        shutil.rmtree(bundle_out, ignore_errors=True)
        copy_bundle(loaded.root, bundle_out / "evidence")
        shutil.copy2(profile, bundle_out / "applicability.yaml")
        if domain_path_early is not None:
            shutil.copy2(domain_path_early, bundle_out / "domain.linkml.yaml")
        if deviations_path is not None:
            shutil.copy2(deviations_path, bundle_out / "deviations.yaml")
        for i, raw_dir in enumerate(raw_catalog_dirs):
            src_dir = _require_dir(
                raw_dir, key="catalog-dir", what="the catalog directory"
            )
            cat = load_catalog(src_dir)
            label = f"{cat.id}@{cat.version}"
            catalog_dir_order.append(label)
            catalog_dir_digests[label] = signing.digest_tree(src_dir)
            shutil.copytree(src_dir, bundle_out / "catalog" / str(i))
    # Stage 2: integrity verification, one IntegrityResult per stream.
    integrity_results = verify_bundle(ingested.accepted, loaded.manifest, loaded.root)
    _write_jsonl((r.to_json() for r in integrity_results), out_dir / "integrity.jsonl")
    # Stage 3: build the provenance graph into the on-disk store (ADR-0001).
    domain_path = _opt_str(ns, "domain")
    domain = (
        DomainBinding.load(
            _require_file(domain_path, key="domain", what="the domain binding")
        )
        if domain_path is not None
        else DomainBinding.empty()
    )
    graph_path = out_dir / "graph.sqlite"
    graph_path.unlink(missing_ok=True)
    graph_store = GraphStore(graph_path)
    build_graph(ingested.accepted, domain=domain, store=graph_store)
    graph_triples = graph_store.triple_count()
    graph_store.close()
    # Stage 4: coverage and reconciliation against independent denominators.
    coverage = compute_coverage(ingested.accepted, profile_obj, loaded.root)
    (out_dir / "coverage.json").write_text(
        json.dumps(coverage, sort_keys=True, indent=2), encoding="utf-8"
    )
    # Stage 5: applicability resolution and drift (catalog controls arrive with item 1.9).
    statements = resolve_applicability(profile_obj, ingested.accepted)
    _write_jsonl(statements, out_dir / "applicability.jsonl")
    drift_findings = sum(len(s["drift"]) for s in statements)
    # Stage 6: catalog evaluation and report artifacts. Each resolved catalog is evaluated
    # against every subject to produce assertions; the report artifacts are rendered from them.
    evaluated = assess_subjects(
        ingested.accepted,
        profile_obj,
        catalogs,
        domain,
        applicability_declared=scanned is None,
    )
    # A records run that judged nothing renders no report: its headline would read "Conformant".
    if scanned is not None and evaluated_nothing(evaluated):
        raise _nothing_evaluated(profile_obj, ingested.accepted, len(evaluated))
    # Stage 6a: incremental state (SPEC §5.4 B7, HR-10). With --state the engine detects a changed
    # bundle (late-arriving evidence lands here), supersedes the prior report, and counts late events.
    state_arg = _opt_str(ns, "state")
    state: StateDir | None = None
    supersedes: list[str] = []
    late_events: dict[str, int] = {}
    runtime_drift: list[dict[str, Any]] = []
    new_window_end = window_end(profile_obj, ingested.accepted)
    # Deviation application (SPEC §13.3.4 Stage 2): lint the register against what this run actually
    # found, apply it, and record the register's digest -- all before Stage 6a's incremental state and
    # `write_report`, so `evaluated`'s flipped outcomes and `limitations`' expired-and-ignored entries
    # are what everything downstream (state, manifest, claim, every rendering) sees.
    deviations: list[dict[str, Any]] = []
    deviation_register_digest: str | None = None
    if deviations_path is not None:
        deviation_file = _require_file(
            deviations_path, key="deviations", what="the deviation register"
        )
        deviations = _load_deviation_register(deviation_file)
        outcomes_by_control: dict[str, set[str]] = {}
        for a in evaluated:
            outcomes_by_control.setdefault(a.control, set()).add(a.outcome)
        control_ids = {c.id for cat in catalogs for c in cat.controls}
        problems = readiness.deviation_lint(
            deviations,
            control_ids=control_ids,
            outcomes_by_control={
                control: frozenset(outcomes)
                for control, outcomes in outcomes_by_control.items()
            },
            as_of=new_window_end,
        )
        if problems:
            raise InputError(
                "input.deviation_invalid",
                f"the deviation register at {deviations_path!r} is invalid: "
                + "; ".join(problems),
                "correct the deviation register and re-run.",
            )
        evaluated, deviation_expired = apply_deviations(
            evaluated, deviations, as_of=new_window_end
        )
        if deviation_expired:
            deviation_cat = messages.catalogue(_opt_str(ns, "report_language") or "en")
            deviation_by_control = deviations_by_control(deviations)
            for control in deviation_expired:
                limitations.append(
                    i18n_format.format_message(
                        deviation_cat["readiness.deviation_expired_ignored"],
                        control=control,
                        expiry=deviation_by_control.get(control, {}).get("expiry", ""),
                    )
                )
        deviation_register_digest = signing.sha256_prefixed(deviation_file.read_bytes())
    if state_arg is not None:
        state = StateDir.load(
            Path(state_arg)
        )  # incompatible state_version aborts with exit 3
        supersedes, late_events = state.plan(
            loaded.digest, ingested.accepted, new_window_end
        )
        # Runtime/continuous conformance (SPEC.md:249 DC-9/HR-10): diff this run's per-(subject,
        # control) outcomes against the state directory's last recorded ones before write_report, so
        # a drifted pair's runtime_drift.jsonl line and its manifest digest land in the same run.
        runtime_drift = state.drift(evaluated)
    command_name = _opt_str(ns, "command_name") or "assess"
    if scanned is not None:
        invocation = ["assess", _scrub_path(str(folder_arg))]
    elif command_name == "quickstart":
        invocation = ["quickstart"]
    else:
        invocation = ["assess", _scrub_path(bundle), _scrub_path(profile)]
    # The actual re-verify invocation a remediation finding names (SPEC §7): unlike `invocation`
    # above (kept positional for backward compatibility with the manifest), this carries every flag
    # needed to reproduce this run's catalog resolution exactly -- `--catalog` (the resolved
    # id@version labels, always reproducible regardless of how they were originally supplied),
    # every `--catalog-dir`, and `--domain` when one was given.
    if scanned is None:
        reverify_argv = [
            "assess",
            "--bundle",
            _scrub_path(bundle),
            "--profile",
            _scrub_path(profile),
        ]
    else:
        reverify_argv = ["assess", _scrub_path(str(folder_arg))]
        if _opt_str(ns, "profile") is not None:
            reverify_argv += ["--profile", _scrub_path(profile)]
    if catalog_labels:
        reverify_argv += ["--catalog", ",".join(catalog_labels)]
    for catalog_dir in list(getattr(ns, "catalog_dir", None) or []):
        reverify_argv += ["--catalog-dir", _scrub_path(catalog_dir)]
    if domain_path is not None:
        reverify_argv += ["--domain", _scrub_path(domain_path)]
    if deviations_path is not None:
        reverify_argv += ["--deviations", _scrub_path(deviations_path)]
    extra_outputs: dict[str, bytes] = {}
    if runtime_drift:
        extra_outputs["runtime_drift.jsonl"] = (
            "\n".join(json.dumps(e, sort_keys=True) for e in runtime_drift) + "\n"
        ).encode("utf-8")
    # Every deterministic output `verify --report` must be able to digest-check (18.8) gets a
    # manifest-tracked entry: these four are written above by Stages 1/2/4/5 directly (not through
    # `write_report`'s own `write_json`/`write_text` helpers), so their bytes are read back once, in
    # this same process, immediately after this run wrote them itself -- not a race, just avoiding a
    # signature change to each stage's own writer.
    for artifact in (
        "quarantine.jsonl",
        "integrity.jsonl",
        "coverage.json",
        "applicability.jsonl",
    ):
        extra_outputs[artifact] = (out_dir / artifact).read_bytes()
    applicability_profile_digest = signing.sha256_prefixed(profile.read_bytes())
    domain_binding_digest = (
        signing.sha256_prefixed(Path(domain_path).read_bytes())
        if domain_path is not None
        else None
    )
    extra_outputs["packaging.json"] = canonicalize(
        {
            "packaged": package_for_sharing,
            "catalog_dir_order": catalog_dir_order,
            "catalog_dir_digests": catalog_dir_digests,
        }
    )
    # "Declared" means named in the profile (None: every profile subject). A derived profile names each
    # agent the scan saw by its own id, so a fresh single-agent run shows nothing undeclared (18.4) and a
    # re-fed profile declares exactly the agent it was derived from. The one exception: a fresh run that
    # discovered several agents declares none of them, since nobody has named them yet (Hill 7).
    declared_subject_ids: frozenset[str] | None = None
    if scanned is not None and declared is None and len(scanned.subjects) > 1:
        declared_subject_ids = frozenset()
    activity = summarize_activity(
        ingested.accepted, profile_obj, declared_subject_ids=declared_subject_ids
    )
    blind_spots = compute_blind_spots(
        evaluated, profile_obj, catalogs, ingested.accepted
    )
    write_report(
        out_dir,
        evaluated,
        bundle_digest=loaded.digest,
        catalogs=catalogs,
        operator=_operator(),
        invocation=invocation,
        supersedes=supersedes,
        report_language=_opt_str(ns, "report_language") or "en",
        limitations=limitations,
        emit=resolved_emit,
        events=ingested.accepted,
        reverify_command=reverify_argv,
        extra_outputs=extra_outputs,
        activity=activity,
        blind_spots=blind_spots,
        applicability_profile_digest=applicability_profile_digest,
        domain_binding_digest=domain_binding_digest,
        deviation_register_digest=deviation_register_digest,
        deviations=deviations,
        profile=profile_obj,
        declared_subject_ids=declared_subject_ids,
        for_preset=for_preset,
        buyer_packaged=package_for_sharing,
    )
    if state is not None:
        state.record(loaded.digest, out_dir / "manifest.json", new_window_end)
    non_conformant = sum(1 for a in evaluated if a.outcome == "non-conformant")
    summary = verdict.summarize(evaluated)
    result.data.update(
        {
            "bundle": str(bundle),
            "bundle_digest": loaded.digest,
            "profile": str(profile),
            "catalogs": catalog_labels,
            "out": out,
            "emit": sorted(resolved_emit),
            "preset": for_preset,
            "preset_source": preset_source,
            "accepted": len(ingested.accepted),
            "quarantined": len(ingested.quarantined),
            "streams": len(integrity_results),
            "graph_triples": graph_triples,
            "subjects": len(coverage["subjects"]),
            "drift_findings": drift_findings,
            "assertions": len(evaluated),
            "summary": summary,
            "activity": activity,
            "blind_spots": blind_spots,
        }
    )
    if scanned is not None:
        result.data["records"] = scanned.summary
        shown = f"{out}/{DERIVED_PROFILE_FILE}" if derived_profile else None
        for line in _records_lines(scanned.summary, shown):
            result.note(line)
    if state is not None:
        result.data["supersedes"] = supersedes
        result.data["late_events"] = late_events
        result.data["runtime_drift"] = runtime_drift
    if limitations:
        # The override is never silent: it is on stderr for the operator and in the manifest and the
        # claim for every later reader (SPEC §8.7).
        result.data["limitations"] = limitations
        for limitation in limitations:
            result.note(limitation)
    if fail_on_predicate is not None:
        # A policy-scoped gate replaces the default any-non-conformant rule: the exit code reflects
        # only the assertions the expression names, never the whole run (SPEC §8.5, finding #29).
        fail_on_matches = sum(1 for a in evaluated if fail_on_predicate(a))
        result.data["fail_on"] = {"expression": fail_on_raw, "matched": fail_on_matches}
        if fail_on_matches:
            result.add_code(int(ExitCode.FINDINGS))
    elif non_conformant:
        result.add_code(int(ExitCode.FINDINGS))
    if evaluated_nothing(evaluated):
        raise _nothing_evaluated(profile_obj, ingested.accepted, len(evaluated))
    catalogue = messages.catalogue(_opt_str(ns, "report_language") or "en")
    if preset_source is not None:
        for line in preset_cli_lines(
            for_preset, preset_source, resolved_emit, catalogue
        ):
            result.note(line)
    for line in activity_cli_lines(activity, catalogue):
        result.note(line)
    for line in blind_spots_cli_lines(blind_spots, catalogue):
        result.note(line)
    for line in _verdict_lines(ns, summary, out, report_written="md" in resolved_emit):
        result.note(line)
    result.note(
        f"assessed {len(evaluated)} (control, subject) pairs; {non_conformant} non-conformant"
    )
    return result


def _records_subject(declared: Profile | None) -> str | None:
    """The subject a records folder is assessed as: the one subject an adopter's own profile declares,
    else ``None`` to let ``scan()`` discover one subject per distinct agent id in the records (18.14 C4).
    A profile declaring several subjects cannot say which of them the records are about."""
    if declared is None:
        return None
    if not declared.subjects:
        raise InputError(
            "input.profile_invalid",
            "the profile declares no subject, so the records have no agent to be about.",
            "declare one subject in the profile, or leave out --profile to use the default one.",
        )
    if len(declared.subjects) > 1:
        raise InputError(
            "input.records_subject_ambiguous",
            f"the profile declares {len(declared.subjects)} subjects, and a records folder is "
            "assessed as one.",
            "declare one subject in the profile, or assess each agent's records folder separately.",
        )
    return declared.subjects[0].id


def _printable(text: str) -> str:
    """``text`` with control characters escaped, so a file name cannot drive the terminal. The
    trigger also fires on the shared ``Default_Ignorable_Code_Point`` predicate
    (:func:`agentce.report.has_invisible_codepoint`), not only ``str.isprintable()`` -- that built-in
    treats variation selectors, CGJ, the Mongolian free variation selectors, and the Hangul filler
    characters as printable, so without this they would pass through raw."""
    return (
        text.encode("unicode_escape").decode("ascii")
        if not text.isprintable() or has_invisible_codepoint(text)
        else text
    )


def _records_lines(summary: dict[str, Any], profile: str | None) -> list[str]:
    """What a records-folder run read, what it could not, and where the default profile is (``None``
    when the adopter passed their own)."""
    lines = [
        f"read {summary['events']} events from {len(summary['files'])} record file(s) "
        f"({summary['spans']} spans; {summary['spans_skipped']} not a GenAI operation the adapter maps)",
    ]
    lines += [
        f"not read: {_printable(item['path'])}: {_printable(item['reason'])}"
        for item in summary["unrecognised"]
    ]
    lines += [
        f"not read: {_printable(item['path'])} line {item['line']}: {_printable(item['reason'])}"
        for item in summary["unrecognised_lines"]
    ]
    if profile is not None:
        lines.append(
            f"default profile: {_printable(profile)} (declare your agents there and pass it back with "
            "--profile to refine the run)"
        )
    return lines


def _verdict_lines(
    ns: argparse.Namespace,
    summary: dict[str, Any],
    out: str,
    *,
    report_written: bool = True,
) -> list[str]:
    """The verdict, tally, top gaps, and next step a run prints, in the report language.
    ``report_written`` is ``False`` when the resolved ``--emit``/``--for`` set has no ``md`` renderer,
    so the next step never points at a ``report.md`` that was never written (SPEC §13.4)."""
    catalogue = messages.catalogue(_opt_str(ns, "report_language") or "en")
    return verdict.cli_lines(
        summary, catalogue, report_dir=out, report_written=report_written
    )


def _effective_trust_root(ns: argparse.Namespace) -> signing.TrustRoot:
    """The trust root catalog verification consults: ``--trust-root``, else ``AGENTCE_TRUST_ROOT``,
    else the trust root vendored in the engine (SPEC §8.7).

    The vendored development root is the default so the engine's own signed catalogs verify offline
    out of the box; a deployment that signs its catalogs with its own keys points either surface at
    its own root, and that root — never the vendored one — is what verification then uses."""
    raw = _opt_str(ns, "trust_root") or os.environ.get("AGENTCE_TRUST_ROOT")
    if raw is None or not raw.strip():
        return signing.vendored_trust()
    path = _require_file(raw, key="trust_root", what="the trust root")
    try:
        return signing.load_trust_root(path)
    except signing.VerificationError as exc:
        raise InputError(
            "input.trust_root_invalid",
            f"the trust root {str(path)!r} could not be loaded: {exc}",
            "pass --trust-root <file> (or set AGENTCE_TRUST_ROOT) to a trust root in the form of "
            "the engine's vendored data/trust/dev-root.json.",
        ) from exc


def _verify_catalog_dirs(
    loaded: list[Catalog], trust: signing.TrustRoot, *, allow_unverified: bool = False
) -> list[str]:
    """Refuse every ``--catalog-dir`` catalog whose signature does not verify (SPEC §8.7).

    A catalog an operator points the engine at is untrusted input: unsigned, signed by a key the
    effective trust root does not know, or signed over different bytes than the directory holds, it
    cannot be evaluated. The refusal happens before any control runs and before anything is written,
    so an unverifiable catalog never produces a report that looks as confident as a verified one.

    ``allow_unverified`` is the operator's explicit ``--allow-unverified-catalog`` override (SPEC
    §8.7): the run proceeds and each unverifiable catalog is returned as a limitation string, which
    the caller records in the manifest and the claim so no reader can mistake the report for one
    produced from verified inputs. The override covers *only* what this function checks — an absent
    or failing signature; the identity cross-check in :func:`_resolve_catalogs` has no override."""
    limitations: list[str] = []
    for catalog in loaded:
        try:
            signing.verify_catalog_directory(catalog.directory, trust)
        except signing.VerificationError as exc:
            if allow_unverified:
                limitations.append(
                    f"catalog {catalog.id}@{catalog.version} at "
                    f"{_scrub_path(catalog.directory)} was used unverified "
                    f"(--allow-unverified-catalog): {exc}"
                )
                continue
            raise InputError(
                "input.catalog_unverified",
                f"the catalog directory {_scrub_path(catalog.directory)} did not verify against "
                f"the effective trust root: {exc}",
                "point --catalog-dir at a catalog whose catalog.sig.json verifies, or pass "
                "--trust-root <file> (or set AGENTCE_TRUST_ROOT) for the root that signed it; "
                "--allow-unverified-catalog assesses it anyway and records the override as a "
                "limitation.",
            ) from exc
    return limitations


def _load_deviation_register(path: Path) -> list[dict[str, Any]]:
    """Load and validate a deviation register's *shape* (SPEC §13.3.4): a mapping with a top-level
    ``deviations`` list of mappings, refused as ``input.deviation_invalid`` rather than crashing on
    hostile or malformed YAML (a non-mapping top level, a ``deviations`` key that is not a list, or a
    non-mapping entry). Every ``granted``/``expiry`` value that YAML parsed as a ``date``/``datetime``
    (an unquoted ``expiry: 2021-12-31``) is normalized to its ISO string form, so an unquoted date
    validates and compares exactly like a quoted one -- ``deviation_lint``'s and
    ``apply_deviations``'s own date checks would otherwise silently treat it as absent, bypassing both
    the 180-day cap and the expiry check. Used by both ``cmd_assess`` and ``cmd_readiness``; this is
    the shape-check only, not full ``deviation-register.schema.json`` validation (``deviation_lint``
    remains the established level of rigor for the register's *content*)."""
    data = (
        load_untrusted_yaml(
            path, key="input.deviation_invalid", what="the deviation register"
        )
        or {}
    )
    if not isinstance(data, dict):
        raise InputError(
            "input.deviation_invalid",
            f"the deviation register at {str(path)!r} is not a mapping.",
            "the register must be a mapping with a top-level `deviations:` list.",
        )
    raw = data.get("deviations", [])
    if not isinstance(raw, list):
        raise InputError(
            "input.deviation_invalid",
            f"the deviation register at {str(path)!r}'s `deviations` key is not a list.",
            "`deviations:` must be a list of deviation entries.",
        )
    entries: list[dict[str, Any]] = []
    for entry in raw:
        if not isinstance(entry, dict):
            raise InputError(
                "input.deviation_invalid",
                f"the deviation register at {str(path)!r} has a deviation entry that is not a "
                "mapping.",
                "each entry under `deviations:` must be a mapping of the register's own fields.",
            )
        entries.append(entry)
    return readiness.normalize_deviation_dates(entries)


def _check_package_path_overlap(
    out_dir: Path,
    bundle: Path,
    profile: Path,
    domain_path: str | None,
    catalog_dirs: list[str],
    deviations_path: str | None = None,
) -> None:
    """Refuse (``input.package_path_overlap``) before anything is written when ``--out`` is, contains,
    or sits inside any input path ``--package-for-sharing`` will copy from (SPEC 18.8 D4): packaging
    would otherwise read from or write into the same tree it is producing (assessing back into the
    bundle it was just given, or a catalog directory that happens to sit inside ``--out`` already)."""
    resolved_out = out_dir.resolve()
    candidates: list[tuple[str, Path]] = [("--bundle", bundle), ("--profile", profile)]
    if domain_path is not None:
        candidates.append(("--domain", Path(domain_path)))
    if deviations_path is not None:
        candidates.append(("--deviations", Path(deviations_path)))
    for raw_dir in catalog_dirs:
        candidates.append(("--catalog-dir", Path(raw_dir)))
    for label, path in candidates:
        try:
            resolved = path.resolve()
        except OSError:
            continue
        if (
            resolved == resolved_out
            or resolved_out.is_relative_to(resolved)
            or resolved.is_relative_to(resolved_out)
        ):
            raise InputError(
                "input.package_path_overlap",
                f"--out {out_dir} overlaps {label} {path}: packaging would read from or write "
                "into the same tree it is producing.",
                "point --out somewhere outside every input path, then re-run.",
            )


def _resolve_catalogs(
    requested: str | None,
    profile: Profile,
    catalog_dirs: list[str],
    trust: signing.TrustRoot,
    *,
    allow_unverified: bool = False,
) -> tuple[list[Catalog], list[str], list[str]]:
    """The catalogs an assessment evaluates, their ``id@version`` labels, and any limitations.

    Each ``--catalog-dir`` is loaded as given (the explicit override) and its signature verified
    against ``trust`` before anything else happens. Each requested id — the ``--catalog`` list, else
    the profile's declared ``catalogs`` when no directory was passed — must resolve to a directory
    that was passed or to a vendored catalog, and every directory that was passed must be one the
    request names. An id that resolves to nothing, a directory the request does not name, or a
    request that names no catalog at all, is an input error: an assessment must not proceed to judge
    nothing, nor to judge something other than what was asked for. A run that passes no ``--catalog``
    and no ``--catalog-dir`` and whose profile declares no catalogs evaluates the baseline
    (``bundled.DEFAULT_LENS``); an explicit but empty ``--catalog`` is still refused.

    The returned limitations are the signature checks ``--allow-unverified-catalog`` waived, for the
    manifest and the claim to record; the list is empty on an ordinary run."""
    loaded = [
        load_catalog(_require_dir(d, key="catalog-dir", what="the catalog directory"))
        for d in catalog_dirs
    ]
    limitations = _verify_catalog_dirs(loaded, trust, allow_unverified=allow_unverified)
    by_label = {f"{c.id}@{c.version}": c for c in loaded}
    if requested:
        ids = [i.strip() for i in requested.split(",") if i.strip()]
    elif catalog_dirs:
        ids = []
    else:
        ids = list(profile.catalogs)
        if not ids and requested is None:
            ids = [bundled.DEFAULT_LENS]
    if not ids and not loaded:
        raise InputError(
            "input.catalog_missing",
            "--catalog was given but names no catalog.",
            "pass --catalog <id@version>, or leave --catalog out to assess against the baseline.",
        )
    unresolved = [i for i in dict.fromkeys(ids) if i not in by_label]
    if unresolved:
        vendored = bundled.vendored_catalogs()
        for label in [u for u in unresolved if u in vendored]:
            by_label[label] = load_catalog(vendored[label])
        unresolved = [u for u in unresolved if u not in vendored]
    if unresolved:
        available = sorted(set(by_label) | set(bundled.vendored_catalogs()))
        raise InputError(
            "input.catalog_unresolved",
            f"no catalog directory resolves {', '.join(repr(u) for u in unresolved)} "
            f"(available: {', '.join(available) or 'none'}).",
            "use an available <id>@<version>, or pass --catalog-dir <dir> for a catalog on disk.",
        )
    # A verified signature proves the bytes were not altered; it does not prove the directory holds
    # the catalog that was asked for. When both a request and a directory were given, every directory
    # must carry an id@version the request names — a rebranded or swapped catalog is refused here even
    # though its own signature verifies. This step is deliberately separate from the signature check
    # above and has no override: SPEC §8.7's --allow-unverified-catalog waives "unsigned or
    # unverifiable", and a catalog whose signature verifies but whose identity is not the one
    # requested is neither, so it is refused whether or not the flag was passed.
    if ids and loaded:
        wanted = set(ids)
        unrequested = [
            f"{c.id}@{c.version}" for c in loaded if f"{c.id}@{c.version}" not in wanted
        ]
        if unrequested:
            raise InputError(
                "input.catalog_mismatch",
                f"a --catalog-dir carries {', '.join(repr(u) for u in unrequested)}, which "
                f"--catalog did not request ({', '.join(repr(i) for i in ids)}).",
                "pass --catalog-dir for the catalog you named, or name the id@version the "
                "directory carries.",
            )
    labels = list(dict.fromkeys([*ids, *(f"{c.id}@{c.version}" for c in loaded)]))
    return [by_label[label] for label in labels], labels, limitations


def _nothing_evaluated(
    profile: Profile, accepted: list[dict[str, Any]], pairs: int
) -> InputError:
    """The exit-3 error for a run whose every (control, subject) pair was inapplicable or unassessed."""
    declared = sorted(s.id for s in profile.subjects)
    seen = sorted({str(e["subject"]) for e in accepted if "subject" in e})
    matched = set(declared) & set(seen)
    if not accepted:
        why = "the bundle has no accepted events"
    elif not matched:
        why = (
            f"none of the {len(accepted)} accepted events is about a subject the profile declares "
            f"(profile: {_ids(declared)}; bundle: {_ids(seen)})"
        )
    else:
        why = (
            f"the {len(accepted)} accepted events give no control an applicable population "
            f"(subjects matched: {_ids(sorted(matched))})"
        )
    return InputError(
        "input.nothing_evaluated",
        f"assessed {pairs} (control, subject) pairs and none reached conformant, non-conformant, "
        f"or insufficient_evidence: {why}. The reports were written, but they judge nothing.",
        "emit under the subject and source the profile declares (agentce-emit reads "
        "AGENTCE_EMIT_SUBJECT and AGENTCE_EMIT_SOURCE), and record the evidence the catalog's "
        "controls apply to.",
    )


def _ids(ids: list[str], cap: int = 3) -> str:
    """A bounded, quoted rendering of identifiers, for a message that must stay one line."""
    shown = ", ".join(repr(i[:80]) for i in ids[:cap]) or "none"
    return shown + (f" and {len(ids) - cap} more" if len(ids) > cap else "")


def _operator() -> str:
    """The run's provenance identity (SPEC §8.4): a string the deployer controls via the
    ``operator`` config key (``AGENTCE_OPERATOR`` or ``agentce.toml``), never the invoking OS
    user by default — the OS username and home directory are not the deployer's to disclose."""
    return str(next(v["value"] for v in resolve_config() if v["key"] == "operator"))


def _scrub_path(path: str | Path) -> str:
    """A path safe to write into a shared artifact (SPEC §8.4: ``invocation`` records paths,
    never a person or their local filesystem layout). Never returns an absolute path: under the
    home directory it becomes ``~/…``; else under the current directory it becomes a relative
    path; anywhere else — a devcontainer's `/workspaces`, an `/opt` checkout, a path outside both
    — only the final path component is kept. Compares the stated path, not where a symlink might
    ultimately point, so a path reached through a symlink under the home directory is still
    caught."""
    p = Path(os.path.abspath(path))
    home = Path(os.path.abspath(Path.home()))
    try:
        return "~/" + p.relative_to(home).as_posix()
    except ValueError:
        pass
    cwd = Path(os.path.abspath(Path.cwd()))
    try:
        return p.relative_to(cwd).as_posix()
    except ValueError:
        pass
    return p.name


def cmd_report(ns: argparse.Namespace) -> CommandResult:
    result = CommandResult(command="report")
    if _flag(ns, "validate"):
        report_dir = _require_dir(
            _opt_str(ns, "validate"), key="validate", what="the report directory"
        )
        problems = validate_report(report_dir)
        result.data.update(
            {"report_dir": str(report_dir), "valid": not problems, "problems": problems}
        )
        if problems:
            result.add_code(int(ExitCode.INPUT_ERROR))
            result.note(f"{report_dir}: {len(problems)} artifact(s) failed validation")
        else:
            result.note(f"{report_dir}: all artifacts valid")
        return result
    source = _require_file(
        _opt_str(ns, "from_"), key="from", what="the assertions file"
    )
    fmt = _opt_str(ns, "format") or "md"
    if fmt not in REPORT_FORMATS:
        raise InputError(
            "input.report_format",
            f"unknown report format {fmt!r}.",
            f"choose one of: {', '.join(REPORT_FORMATS)}.",
        )
    assertions = [Assertion.from_json(a) for a in json.loads(source.read_text("utf-8"))]
    counts = aggregate(assertions)
    catalogs = [c for c in (_opt_str(ns, "catalog") or "").split(",") if c] or None
    language = _opt_str(ns, "language") or "en"
    rendering: str
    if fmt == "md":
        rendering = render_report_md(assertions, counts, language=language)
    elif fmt == "html":
        rendering = render_report_html(assertions, counts, language=language)
    elif fmt == "oscal":
        rendering = json.dumps(render_oscal(assertions), sort_keys=True, indent=2)
    elif fmt == "sarif":
        rendering = json.dumps(render_sarif(assertions), sort_keys=True, indent=2)
    elif fmt == "public":
        rendering = render_public_statement(
            assertions,
            catalogs=catalogs,
            deviations=applied_deviation_ids(assertions),
        )
    else:  # pack
        role = _opt_str(ns, "role")
        by_subject: dict[str, list[Assertion]] = {}
        for assertion in assertions:
            by_subject.setdefault(assertion.subject, []).append(assertion)
        packs = {
            subject: render_evidence_pack(subject, subject_assertions, role=role)
            for subject, subject_assertions in sorted(by_subject.items())
        }
        rendering = json.dumps(packs, sort_keys=True, indent=2)
    result.data.update({"from": str(source), "format": fmt, "rendering": rendering})
    out = _opt_str(ns, "out")
    if out is not None:
        Path(out).write_text(rendering, encoding="utf-8")
        result.data["out"] = out
    result.note(rendering)
    return result


def _adapt_export(
    adapters_root: Path,
    adapter: str,
    export_path: Path,
    *,
    subject: str,
    source_class: str,
    source: str | None = None,
    engine: str | None = None,
) -> list[dict[str, Any]]:
    """Adapt ``export_path`` through ``adapter``, in that adapter's own environment.

    Every v1 adapter package shares the name ``agentce_adapters``, so it cannot be imported directly
    alongside another; this shells out to ``adapters/_ingest.py`` in the adapter's own ``uv`` project,
    mirroring the engine conformance suite's own subprocess pattern for the identical reason.
    """
    adapter_dir = adapters_root / adapter
    if not adapter_dir.is_dir():
        raise InputError(
            "input.adapter_not_found",
            f"no adapter directory at {adapter_dir}.",
            "pass --adapters-root pointing at the adapters checkout, or check the adapter name.",
        )
    script = adapters_root / "_ingest.py"
    cmd = [
        "uv",
        "run",
        "--project",
        str(adapter_dir),
        "--frozen",
        "--quiet",
        "python",
        str(script),
        str(adapter_dir),
        str(export_path),
        "--subject",
        subject,
        "--source-class",
        source_class,
    ]
    if source:
        cmd += ["--source", source]
    if engine:
        cmd += ["--engine", engine]
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if proc.returncode != 0:
        raise InputError(
            "input.ingest_failed",
            f"adapter {adapter!r} could not adapt {export_path}: "
            f"{(proc.stderr or proc.stdout).strip()[-400:]}",
            "check the export file matches the adapter's expected shape.",
        )
    try:
        payload = json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        raise InputError(
            "input.ingest_failed",
            f"adapter {adapter!r} printed a non-JSON result for {export_path}: {exc}.",
            "check the export file matches the adapter's expected shape.",
        ) from exc
    if "error" in payload:
        raise InputError(
            "input.ingest_failed",
            f"adapter {adapter!r}: {payload['error']}",
            "check the export file matches the adapter's expected shape.",
        )
    return list(payload["events"])


def _write_event_bundle(
    out_dir: Path, events: list[dict[str, Any]], *, adapter: str
) -> None:
    """Write ``events`` to an evidence bundle at ``out_dir`` (``events/*.jsonl`` + ``manifest.json``)."""
    out_dir.mkdir(parents=True, exist_ok=True)
    events_dir = out_dir / "events"
    events_dir.mkdir(exist_ok=True)
    stream = events_dir / "stream.jsonl"
    stream.write_text(
        "".join(canonical_string(event) + "\n" for event in events), encoding="utf-8"
    )
    digest = hashlib.sha256(stream.read_bytes()).hexdigest()
    source_classes = {
        str(event["source"]): str(event["agentcesourceclass"]) for event in events
    }
    manifest = {
        "agentce_bundle_version": 1,
        "sources": [
            {"id": source, "adapter": adapter, "class": cls}
            for source, cls in sorted(source_classes.items())
        ],
        "files": [{"path": "events/stream.jsonl", "sha256": digest}],
    }
    (out_dir / "manifest.json").write_text(
        json.dumps(manifest, sort_keys=True, indent=2) + "\n", encoding="utf-8"
    )


def cmd_ingest(ns: argparse.Namespace) -> CommandResult:
    result = CommandResult(command="ingest")
    in_path = _require_file(
        _opt_str(ns, "in_path"), key="in", what="the adapter export file"
    )
    out = _opt_str(ns, "out")
    if not out:
        raise InputError(
            "input.out_missing",
            "ingest needs an output bundle path.",
            "pass --out <bundle>.",
        )
    adapter = _opt_str(ns, "adapter")
    if not adapter:
        raise InputError(
            "input.adapter_missing",
            "ingest needs an adapter.",
            "pass --adapter, e.g. --adapter otel-genai.",
        )
    adapters_root = Path(_opt_str(ns, "adapters_root") or "adapters")
    subject = _opt_str(ns, "subject") or DEFAULT_SUBJECT
    source_class = _opt_str(ns, "source_class") or "self_report"
    source = _opt_str(ns, "source")
    engine = _opt_str(ns, "engine")

    events = _adapt_export(
        adapters_root,
        adapter,
        in_path,
        subject=subject,
        source_class=source_class,
        source=source,
        engine=engine,
    )
    if not events:
        raise InputError(
            "input.ingest_empty",
            f"adapter {adapter!r} produced no events from {in_path}.",
            "check the export file actually contains records the adapter recognizes.",
        )
    out_dir = Path(out)
    _write_event_bundle(out_dir, events, adapter=adapter)
    result.data.update(
        {
            "in": str(in_path),
            "out": str(out_dir),
            "adapter": adapter,
            "events": len(events),
        }
    )
    result.note(
        f"ingested {len(events)} event(s) from {in_path} via {adapter} into {out_dir}"
    )
    return result


@dataclass
class _SubprocessExportAdapter:
    """The engine's ``ExportAdapter`` (SPEC §5.4): runs a source's named adapter as a subprocess."""

    adapters_root: Path

    def adapt(self, source: SourceSpec, export_path: Path) -> list[dict[str, Any]]:
        return _adapt_export(
            self.adapters_root,
            source.adapter,
            export_path,
            subject=source.subject or DEFAULT_SUBJECT,
            source_class=source.source_class or "self_report",
            source=source.id,
            engine=source.engine,
        )


def cmd_collect(ns: argparse.Namespace) -> CommandResult:
    result = CommandResult(command="collect")
    config_path = _require_file(
        _opt_str(ns, "config"), key="config", what="the collection config"
    )
    out = _opt_str(ns, "out")
    dry_run = _flag(ns, "dry_run")
    if not dry_run and not out:
        raise InputError(
            "input.out_missing",
            "a real collection needs an output bundle path.",
            "pass --out <bundle>, or --dry-run to plan only.",
        )
    config = load_config(config_path)
    adapters_root = Path(_opt_str(ns, "adapters_root") or "adapters")
    outcome = run_collect(
        config,
        out_dir=Path(out) if out else None,
        dry_run=dry_run,
        secret_manager=EnvSecretManager(),
        export_adapter=None if dry_run else _SubprocessExportAdapter(adapters_root),
    )
    result.data.update({"config": str(config_path), "dry_run": dry_run})
    if out is not None:
        result.data["out"] = out
        result.data["written"] = list(outcome.written)
    result.data.update(outcome.report)
    if dry_run:
        result.note(
            f"COLLECT DRY-RUN OK: planned {len(config.sources)} source(s), offline, "
            "no credentials resolved"
        )
    else:
        complete_count = sum(
            1 for s in outcome.report["sources"] if s.get("completeness") == "complete"
        )
        incomplete = sum(
            1
            for s in outcome.report["sources"]
            if s.get("completeness") == "incomplete"
        )
        result.note(
            f"collected {complete_count} of {len(config.sources)} source(s); {incomplete} incomplete"
        )
    if not outcome.complete:
        result.add_code(int(ExitCode.FINDINGS))
    return result


def _reject_inside_catalog(
    value: str,
    catalog_dir: Path,
    *,
    key: str,
    flag: str,
    noun: str,
    shown_dir: Path,
) -> None:
    """Raise ``InputError(key)`` if `value` resolves inside `catalog_dir` -- an operator-supplied path
    for something that must live outside the catalog it's paired with (a support matrix, a signing
    key, a trust root)."""
    if Path(value).resolve().is_relative_to(catalog_dir):
        raise InputError(
            key,
            f"{flag} {value!r} resolves inside the catalog directory {shown_dir}.",
            f"write the {noun} outside the catalog directory.",
        )


def cmd_catalog(ns: argparse.Namespace) -> CommandResult:
    result = CommandResult(command="catalog")
    action = _opt_str(ns, "catalog_action")
    if action == "coverage-matrix":
        return _cmd_coverage_matrix(ns)
    if action == "init":
        return _cmd_catalog_init(ns)
    if action == "sign":
        return _cmd_catalog_sign(ns)
    if action != "lint":
        raise InputError(
            "input.catalog_action",
            "the catalog actions are `lint`, `coverage-matrix`, `init`, and `sign`.",
            "run `agentce catalog lint <dir>`, `agentce catalog coverage-matrix <dir>`, "
            "`agentce catalog init <dir>`, or `agentce catalog sign <dir>`.",
        )
    directory = _require_dir(
        _opt_str(ns, "dir"),
        key="dir",
        what="the catalog directory",
        fix="pass the catalog directory: `agentce catalog lint <dir>`.",
    )
    # Lint the catalog at `directory`, or every catalog beneath it (so `catalog lint spec/catalogs`
    # lints the whole tree, not just a directory that itself holds a catalog.yaml).
    if (directory / "catalog.yaml").is_file():
        catalog_dirs = [directory]
    else:
        catalog_dirs = sorted({p.parent for p in directory.rglob("catalog.yaml")})
    support_matrix = _opt_str(ns, "support_matrix")
    if support_matrix is not None:
        if len(catalog_dirs) > 1:
            raise InputError(
                "catalog.support_matrix_multi",
                f"--support-matrix needs exactly one catalog, but {directory} holds "
                f"{len(catalog_dirs)}.",
                "pass the single catalog's own directory, not a directory holding several.",
            )
        if catalog_dirs:
            _reject_inside_catalog(
                support_matrix,
                catalog_dirs[0].resolve(),
                key="catalog.support_matrix_inside_catalog",
                flag="--support-matrix",
                noun="support matrix",
                shown_dir=catalog_dirs[0],
            )
    problems: list[str] = []
    if not catalog_dirs:
        problems.append(f"{directory}: no catalog.yaml (and none beneath it)")
    require_flags = _flag(ns, "require_verification_flags")
    require_prov = _flag(ns, "require_provenance")
    for cat_dir in catalog_dirs:
        prefix = "" if len(catalog_dirs) == 1 else f"{cat_dir.relative_to(directory)}: "
        problems.extend(
            f"{prefix}{p}"
            for p in lint_catalog(
                cat_dir,
                require_verification_flags=require_flags,
                require_provenance=require_prov,
            )
        )
    result.data.update(
        {
            "action": "lint",
            "dir": str(directory),
            "catalogs": [str(d) for d in catalog_dirs],
            "clean": not problems,
            "problems": problems,
        }
    )
    if support_matrix is not None and catalog_dirs:
        catalog = load_catalog(catalog_dirs[0])
        view = catalog_support_view(catalog)
        sm_path = Path(support_matrix)
        sm_path.parent.mkdir(parents=True, exist_ok=True)
        sm_path.write_text(
            json.dumps(
                {"catalog": catalog.id, "version": catalog.version, "controls": view},
                indent=2,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
        result.data["support_matrix"] = str(sm_path)
    if problems:
        result.add_code(int(ExitCode.FINDINGS))
        result.note(f"CATALOG FAILED: {directory}: {len(problems)} problem(s)")
        for problem in problems:
            result.note(f"  {problem}")
    else:
        result.note(f"CATALOG OK: {directory}")
    return result


#: The control-family prefix `catalog init` accepts (`control.schema.json`'s own id-prefix pattern).
_FAMILY_RE = re.compile(r"^[A-Z]{2,4}$")


def _vendored_control_families() -> frozenset[str]:
    """Every control-family prefix a vendored base or overlay catalog already uses, computed fresh
    each call from `bundled.vendored_catalogs()` so it never drifts from what actually ships."""
    families: set[str] = set()
    for directory in bundled.vendored_catalogs().values():
        for control in load_catalog(directory).controls:
            family = control.id.split("-", 1)[0]
            if family:
                families.add(family)
    return frozenset(families)


def _default_family(dir_path: Path) -> str:
    """The `--id` `catalog init` uses when none is given: `dir_path`'s own resolved directory name,
    uppercased and filtered to letters, truncated to 4 -- falling back to `GEN` when that yields
    fewer than 2 letters (a `.`, a trailing slash, or a non-ASCII name)."""
    letters = "".join(ch for ch in dir_path.resolve().name.upper() if ch.isalpha())[:4]
    return letters if len(letters) >= 2 else "GEN"


def _cmd_catalog_init(ns: argparse.Namespace) -> CommandResult:
    """Scaffold a from-scratch, lint-clean, `mode: automated` custom catalog (SPEC §7.3)."""
    result = CommandResult(command="catalog")
    directory = Path(_opt_str(ns, "dir") or ".")
    family = _opt_str(ns, "family")
    if family is None:
        family = _default_family(directory)
    elif not _FAMILY_RE.match(family):
        raise InputError(
            "catalog.init_family_invalid",
            f"--id {family!r} must be 2-4 uppercase letters.",
            "pass --id as 2-4 uppercase letters, e.g. --id ACM.",
        )
    if family in _vendored_control_families():
        raise InputError(
            "catalog.init_family_collision",
            f"the control family {family!r} is already used by a vendored catalog.",
            "pass a different --id.",
        )
    title = _opt_str(ns, "title") or f"{family} custom catalog"
    slug = re.sub(r"[^a-z0-9]+", "-", directory.resolve().name.lower()).strip("-") or (
        "custom-catalog"
    )
    version = date.today().strftime("%Y.%m")

    catalog_yaml = directory / "catalog.yaml"
    control_yaml = directory / "controls" / f"{family}-01.yaml"
    shape_ttl = directory / "shapes" / f"{family}-01.ttl"
    domain_yaml = directory / "test" / "domain.yaml"
    fixtures_dir = directory / "test" / f"{family}-01"
    passed_jsonl = fixtures_dir / "passed.jsonl"
    failed_jsonl = fixtures_dir / "failed.jsonl"
    inapplicable_jsonl = fixtures_dir / "inapplicable.jsonl"
    files = [
        catalog_yaml,
        control_yaml,
        shape_ttl,
        domain_yaml,
        passed_jsonl,
        failed_jsonl,
        inapplicable_jsonl,
    ]
    existing = [str(p) for p in files if p.exists()]
    if existing and not _flag(ns, "force"):
        raise InputError(
            "catalog.init_exists",
            f"catalog init would overwrite {', '.join(existing)}.",
            "pass --force to overwrite, or a different <dir>.",
        )

    catalog_doc = {
        "id": slug,
        "version": version,
        "title": title,
        "kind": "overlay",
        "families": [family],
        "controls": [f"controls/{family}-01.yaml"],
    }
    control_doc = {
        "id": f"{family}-01",
        "version": version,
        "title": f"{family}-01 custom control",
        "crosswalk": [
            {
                "framework": "nist-ai-rmf",
                "clause": "GOVERN-1.1",
                "relation": "supports",
                "verified_against_text": False,
            }
        ],
        "applicability": {"applies_to_roles": ["both"]},
        "evaluation": {
            "mode": "automated",
            "rung": 2,
            "min_source_class": "self_report",
            "minimum_evidence": [{"event": "Decision", "class": "self_report"}],
            "shape": f"shapes/{family}-01.ttl",
        },
        "expectations": [
            {
                "id": "S1",
                "text": "Consequential decisions record who is associated with them.",
            }
        ],
        "severity": "high",
        "evidence_strength": "strong",
        "tolerance": {"kind": "count", "max": 0},
        "test_cases": [
            {
                "id": "pass",
                "expected": "passed",
                "fixture": f"test/{family}-01/passed.jsonl",
            },
            {
                "id": "fail",
                "expected": "failed",
                "fixture": f"test/{family}-01/failed.jsonl",
            },
            {
                "id": "na",
                "expected": "inapplicable",
                "fixture": f"test/{family}-01/inapplicable.jsonl",
            },
        ],
    }
    shape_text = (
        "@prefix sh: <http://www.w3.org/ns/shacl#> .\n"
        "@prefix prov: <http://www.w3.org/ns/prov#> .\n"
        "@prefix agentce: <https://agent-conformance.org/vocab/evidence/v1#> .\n\n"
        f"agentce:{family}-01-Shape a sh:NodeShape ;\n"
        "  sh:targetClass agentce:ConsequentialDecision ;\n"
        '  sh:property [ sh:path prov:wasAssociatedWith ; sh:minCount 1 ; sh:name "S1" ] .\n'
    )
    domain_text = (
        "# Domain binding used only by this catalog's own lint fixtures (SPEC 6.5).\n"
        "decision_types:\n"
        '  - {id: "dom:Credit", subclass_of: "agentce:ConsequentialDecision", consequential: true}\n'
        '  - {id: "dom:Minor", subclass_of: "agentce:Decision", consequential: false}\n'
    )
    _decision_line = (
        '{{"id":"d1","source":"urn:src:self_report","subject":"spiffe://corp/agents/a",'
        '"type":"org.agent-conformance.evidence.Decision.v1","agentcesourceclass":"self_report",'
        '"data":{{"@type":"Decision","decision_type":"{decision_type}"{agent}}},'
        '"time":"2026-01-01T00:00:00Z"}}\n'
    )
    passed_text = _decision_line.format(
        decision_type="dom:Credit", agent=',"agent":{"id":"spiffe://corp/agents/a"}'
    )
    failed_text = _decision_line.format(decision_type="dom:Credit", agent="")
    inapplicable_text = _decision_line.format(
        decision_type="dom:Minor", agent=',"agent":{"id":"spiffe://corp/agents/a"}'
    )

    for path in (catalog_yaml, control_yaml, shape_ttl, domain_yaml):
        path.parent.mkdir(parents=True, exist_ok=True)
    fixtures_dir.mkdir(parents=True, exist_ok=True)
    catalog_yaml.write_text(
        yaml.safe_dump(catalog_doc, sort_keys=False, default_flow_style=False),
        encoding="utf-8",
    )
    control_yaml.write_text(
        yaml.safe_dump(control_doc, sort_keys=False, default_flow_style=False),
        encoding="utf-8",
    )
    shape_ttl.write_text(shape_text, encoding="utf-8")
    domain_yaml.write_text(domain_text, encoding="utf-8")
    passed_jsonl.write_text(passed_text, encoding="utf-8")
    failed_jsonl.write_text(failed_text, encoding="utf-8")
    inapplicable_jsonl.write_text(inapplicable_text, encoding="utf-8")

    result.data.update(
        {
            "dir": str(directory),
            "id": slug,
            "family": family,
            "title": title,
            "version": version,
            "files": [str(p) for p in files],
        }
    )
    result.note(
        f"wrote a scaffolded catalog to {directory} (family {family}); next: "
        f"`agentce catalog lint {directory} --support-matrix <path>`, "
        f"`agentce catalog sign {directory} --new-key <path> --write-trust-root <path>`, and "
        f"`agentce assess --catalog-dir {directory} --trust-root <path> --bundle ... --profile ...`."
    )
    return result


def _cmd_coverage_matrix(ns: argparse.Namespace) -> CommandResult:
    result = CommandResult(command="catalog")
    directory = _require_dir(
        _opt_str(ns, "dir"),
        key="dir",
        what="the catalog directory",
        fix="pass the catalog directory: `agentce catalog coverage-matrix <dir>`.",
    )
    if _flag(ns, "check"):
        ok, message = check_matrix(directory)
        result.data.update(
            {"action": "coverage-matrix", "dir": str(directory), "matrix_ok": ok}
        )
        if ok:
            result.note(f"MATRIX OK: {directory}")
        else:
            result.add_code(int(ExitCode.FINDINGS))
            result.note(f"MATRIX FAILED: {message}")
        return result
    written = write_matrix(directory)
    result.data.update(
        {"action": "coverage-matrix", "dir": str(directory), "written": str(written)}
    )
    result.note(f"wrote {MATRIX_FILE} for {directory}")
    return result


def cmd_conformance(ns: argparse.Namespace) -> CommandResult:
    result = CommandResult(command="conformance")
    action = _opt_str(ns, "conformance_action")
    if action != "run":
        raise InputError(
            "input.conformance_action",
            "the only conformance action is `run`.",
            "run `agentce conformance run ...`.",
        )
    engine = _require_dir(_opt_str(ns, "engine"), key="engine", what="the engine path")
    corpus = _require_dir(
        _opt_str(ns, "corpus"), key="corpus", what="the corpus directory"
    )
    out = _opt_str(ns, "out")
    adapters = _opt_str(ns, "adapters")
    adapters_dir = (
        _require_dir(adapters, key="adapters", what="the adapters directory")
        if adapters is not None
        else None
    )
    report = run_ecs(
        engine_path=engine,
        corpus_dir=corpus,
        out_dir=Path(out) if out else None,
        adapters_dir=adapters_dir,
    )
    result.data.update({"action": "run", "engine": str(engine), "corpus": str(corpus)})
    if out is not None:
        result.data["out"] = out
    result.data.update(report)
    result.note(
        f"ECS: {report['projects']['identical']}/{report['projects']['total']} identical; "
        f"claim {report['claim']}; no_ml {report['no_ml']}"
    )
    adapters_claim = report.get("adapters")
    detail = report.get("adapter_conformance")
    if isinstance(adapters_claim, str) and isinstance(detail, dict):
        result.note(
            f"adapters: {detail.get('identical')}/{detail.get('total')} identical; "
            f"round_trip {detail.get('round_trip')}; claim {adapters_claim}"
        )
    if report["claim"] != "full":
        result.add_code(int(ExitCode.FINDINGS))
    if adapters_claim is not None and adapters_claim != "full":
        result.add_code(int(ExitCode.FINDINGS))
    return result


def _diff_string_field(entry: dict[str, Any], field: str) -> str:
    """``entry[field]``, required to already be a JSON string. A structurally-absent key is an
    uncaught ``KeyError`` (mirrors every other command's malformed-input path in this engine, not
    newly introduced here); a present-but-non-string value (a number, boolean, ``null``, object, or
    array) raises a keyed ``input.diff_field_not_string`` instead of silently coercing it with
    ``str()`` -- all three engines refuse this input the same way (TRADEOFFS.md, 2026-09-30)."""
    value = entry[field]
    if not isinstance(value, str):
        raise InputError(
            "input.diff_field_not_string",
            f"assertion field {field!r} must be a string, not {value!r}.",
            "emit control/subject/outcome as JSON strings.",
        )
    return value


def _diff_assertion_sets(
    a: list[dict[str, Any]], b: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """A real, content-keyed delta between two assertion sets: every ``(control, subject)`` whose
    outcome changed, added, or was removed -- keyed by identity, never by array position, so the
    result is independent of either input's element order."""

    def by_key(entries: list[dict[str, Any]]) -> dict[tuple[str, str], str]:
        return {
            (
                _diff_string_field(e, "control"),
                _diff_string_field(e, "subject"),
            ): _diff_string_field(e, "outcome")
            for e in entries
        }

    left, right = by_key(a), by_key(b)
    changes = []
    for key in sorted(set(left) | set(right)):
        before, after = left.get(key), right.get(key)
        if before != after:
            control, subject = key
            changes.append(
                {"control": control, "subject": subject, "from": before, "to": after}
            )
    return changes


def _diff_field(value: str | None) -> str:
    """``value`` sanitised for the terminal, or the fixed literal ``(none)`` when the key was absent
    on one side of the diff (an added or removed assertion) -- never passed into the sanitiser, whose
    empty-placeholder logic means something different (a string that neutralises to nothing), and
    never rendered as a bare, silently-blank field."""
    return sanitize_for_terminal(value) if value is not None else "(none)"


#: ``agentce diff --format``'s three renderings (SPEC §9.3): today's flat human-note list, the
#: machine-readable ``what_changed`` object standalone, and a Markdown "## What changed" section.
DIFF_FORMATS = ("text", "json", "md")


def _classify_change(before: str | None, after: str | None) -> str:
    """One of ``"closed"``, ``"opened"``, ``"other"`` for a single ``(before, after)`` outcome pair
    (SPEC §9.3; item 18.6): ``"closed"`` iff ``before`` was a gap (:data:`agentce.verdict.GAP_OUTCOMES`,
    which already includes ``not_assessed``) and ``after`` is ``"conformant"``; ``"opened"`` iff the
    reverse. The two conditions cannot both hold -- ``"conformant"`` is not itself a member of
    ``GAP_OUTCOMES`` -- so every pair lands in exactly one bucket. An added or removed assertion (either
    side ``None``) and any pair touching ``"not_applicable"`` (a scope change, not a regression or a fix)
    always land in ``"other"``; an out-of-vocabulary outcome string does too, by the same plain string
    comparison, with no special-casing."""
    if before in GAP_OUTCOMES and after == "conformant":
        return "closed"
    if before == "conformant" and after in GAP_OUTCOMES:
        return "opened"
    return "other"


def _what_changed(changes: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    """Group ``changes`` (``_diff_assertion_sets``'s own output, already sorted by ``(control,
    subject)``) by :func:`_classify_change`, preserving that order within each of the three groups so
    the grouping is a stable, cross-engine output contract (item 18.24 reproduces this byte-for-byte)."""
    what_changed: dict[str, list[dict[str, Any]]] = {
        "closed": [],
        "opened": [],
        "other": [],
    }
    for change in changes:
        what_changed[_classify_change(change["from"], change["to"])].append(change)
    return what_changed


def _diff_change_line(change: dict[str, Any]) -> str:
    """``control @ subject: from -> to``, sanitised -- the one line both the text and md formats
    render for a single change, so the two renderings cannot drift apart from each other."""
    control = sanitize_for_terminal(change["control"])
    subject = sanitize_for_terminal(change["subject"])
    return f"{control} @ {subject}: {_diff_field(change['from'])} -> {_diff_field(change['to'])}"


def _diff_md_lines(what_changed: dict[str, list[dict[str, Any]]]) -> list[str]:
    """The ``--format md`` "## What changed" section as a list of lines (one per ``result.note()``
    call): one ``### <Label> (<n>)`` subsection per **non-empty** group only, in ``closed``, ``opened``,
    ``other`` order, each a bullet list built from the same fields the text format already renders."""
    groups = (("closed", "Closed"), ("opened", "Opened"), ("other", "Other changes"))
    non_empty = [
        (label, what_changed[key]) for key, label in groups if what_changed[key]
    ]
    if not non_empty:
        return ["## What changed", "", "no differences."]
    lines = ["## What changed"]
    for label, group in non_empty:
        lines.append("")
        lines.append(f"### {label} ({len(group)})")
        lines.extend(f"- {_diff_change_line(change)}" for change in group)
    return lines


def cmd_diff(ns: argparse.Namespace) -> CommandResult:
    result = CommandResult(command="diff")
    extra = list(getattr(ns, "extra", None) or [])
    if extra:
        raise InputError(
            "input.diff_extra_argument",
            f"diff takes exactly two positional arguments, got {2 + len(extra)}.",
            "pass exactly two files: `agentce diff <report-a> <report-b>`.",
        )
    fix = "pass two assertion files: `agentce diff <report-a> <report-b>`."
    left = _require_file(
        _opt_str(ns, "report_a"),
        key="report_a",
        what="the first assertion set",
        fix=fix,
    )
    right = _require_file(
        _opt_str(ns, "report_b"),
        key="report_b",
        what="the second assertion set",
        fix=fix,
    )
    fmt = _opt_str(ns, "format") or "text"
    if fmt not in DIFF_FORMATS:
        raise InputError(
            "input.diff_format",
            f"--format must be one of {', '.join(DIFF_FORMATS)}, not {fmt!r}.",
            "pass --format text|json|md.",
        )
    result.data.update({"report_a": str(left), "report_b": str(right)})
    a = json.loads(left.read_text("utf-8"))
    b = json.loads(right.read_text("utf-8"))
    changes = _diff_assertion_sets(a, b)
    what_changed = _what_changed(changes)
    result.data["changed"] = len(changes)
    result.data["diff"] = changes
    result.data["what_changed"] = what_changed
    if changes:
        result.add_code(int(ExitCode.FINDINGS))
    if _flag(ns, "json"):
        # `_emit_result` (cli.py) prints only the envelope under --json and never reads
        # `result.human_lines`, so rendering any format's notes here would be pure wasted work.
        return result
    if fmt == "md":
        for line in _diff_md_lines(what_changed):
            result.note(line)
    elif fmt == "json":
        result.note(json.dumps(result.data, indent=2, sort_keys=True))
    elif changes:
        result.note(f"{len(changes)} assertion(s) differ:")
        for c in changes:
            result.note(f"  {_diff_change_line(c)}")
    else:
        result.note("no differences")
    return result


def cmd_sign(ns: argparse.Namespace) -> CommandResult:
    result = CommandResult(command="sign")
    report_dir = _require_dir(
        _opt_str(ns, "report_dir"),
        key="report_dir",
        what="the report directory",
        fix="pass the report directory: `agentce sign <report-dir> --as claimant|assessor`.",
    )
    role = _opt_str(ns, "as_role")
    if role not in SIGN_ROLES:
        raise InputError(
            "input.sign_role",
            "--as must be `claimant` or `assessor`.",
            "pass --as claimant|assessor.",
        )
    profile = _opt_str(ns, "profile") or "sigstore-public"
    if profile not in SIGN_PROFILES:
        raise InputError(
            "input.sign_profile",
            f"unknown signing profile {profile!r}.",
            f"choose one of: {', '.join(SIGN_PROFILES)}.",
        )
    write_trust_root = _flag(ns, "write_trust_root")
    if write_trust_root and profile != "kms":
        raise InputError(
            "sign.trust_root_requires_kms",
            f"--write-trust-root needs an exportable public key; the {profile!r} profile has none.",
            "pass --profile kms --key <ed25519-private-key.pem> --write-trust-root.",
        )
    dry_run = _flag(ns, "dry_run")
    result.data.update(
        {
            "report_dir": str(report_dir),
            "as": role,
            "profile": profile,
            "dry_run": dry_run,
        }
    )

    # The engine refuses to sign a report that is not ready to publish (SPEC §8.5).
    verdict = readiness.compute_readiness(
        report_dir, severities=_readiness_severities(ns)
    )
    result.data["readiness"] = verdict["verdict"]
    if verdict["verdict"] == readiness.NOT_READY:
        raise InputError(
            "sign.not_ready",
            f"the report is {verdict['verdict']}: {'; '.join(verdict['reasons'])}.",
            "resolve the blocking reasons (agentce readiness <report-dir>) before signing.",
        )

    if dry_run:
        result.note(f"dry run: would sign the claim as {role} ({profile})")
        return result

    claim_path = report_dir / "claim.json"
    if not claim_path.is_file():
        raise InputError(
            "sign.no_claim",
            "the report directory has no claim.json to sign.",
            "produce the report first: `agentce assess … --out <report-dir>`.",
        )
    claim = json.loads(claim_path.read_text("utf-8"))

    signer = _sign_signer(ns, profile)
    subjects = _sign_subjects(report_dir, claim)
    statement = {
        "_type": signing.INTOTO_STATEMENT_TYPE,
        "subject": subjects,
        "predicateType": "https://agent-conformance.org/attestation/claim/v1",
        "predicate": {
            "role": role,
            "profile": profile,
            "statement": (
                "This report states conformance to the named catalogs as evaluated by the named "
                "engine over the named evidence. It is not a legal compliance determination."
            ),
        },
    }
    envelope = signing.sign_statement(statement, signer)
    record = {"role": role, "profile": profile, **envelope}
    claim.setdefault("signatures", []).append(record)
    claim_path.write_text(
        json.dumps(claim, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    sig_dir = report_dir / "signatures"
    sig_dir.mkdir(exist_ok=True)
    detached = sig_dir / f"{role}-{profile}.dsse.json"
    detached.write_text(
        json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    result.data.update(
        {
            "signature": str(detached),
            "keyid": signer.keyid,
            "signatures": len(claim["signatures"]),
        }
    )
    if write_trust_root:
        # A recipient of a shareable report bundle (18.8, Hill 3) verifies it with `agentce verify
        # --report`, which needs this signer's public key; publishing it inside the report directory
        # itself means no separate key exchange is required for the common case (D6's embedded-trust
        # exception applies, and is called out to the recipient there).
        assert isinstance(signer, signing.KmsSigner)
        trust_root_path = report_dir / "trust-root.json"
        trust_root_path.write_text(
            json.dumps(
                signing.TrustRoot.document(
                    signer.keyid,
                    signer.public_key_b64,
                    claim.get("claimant", {}).get("org", "unset"),
                ),
                indent=2,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
        result.data["trust_root"] = str(trust_root_path)
    result.note(f"signed {claim_path.name} as {role} ({profile})")
    return result


def _sign_subjects(report_dir: Path, claim: dict[str, Any]) -> list[dict[str, Any]]:
    """The in-toto subjects a claim signature covers: the claim body and the manifest, by digest."""
    body = {k: v for k, v in claim.items() if k != "signatures"}
    subjects = [
        {
            "name": "claim.json",
            "digest": {"sha256": hashlib.sha256(canonicalize(body)).hexdigest()},
        }
    ]
    manifest_path = report_dir / "manifest.json"
    if manifest_path.is_file():
        subjects.append(
            {
                "name": "manifest.json",
                "digest": {
                    "sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest()
                },
            }
        )
    return subjects


def _sign_signer(ns: argparse.Namespace, profile: str) -> signing.Signer:
    """Resolve the operator's signing key for ``agentce sign`` (SPEC §9.1).

    ``kms`` signs with an operator-held key passed as ``--key`` (Ed25519 PEM); the engine holds no
    signing identity of its own. The keyless ``sigstore-*`` profiles obtain a short-lived certificate
    from a Fulcio instance, which needs network and is exercised by the release tooling; ``agentce
    sign`` reports the requirement rather than pretending to reach it offline.
    """
    key_path = _opt_str(ns, "key")
    if profile == "kms":
        if not key_path:
            raise InputError(
                "sign.kms_key_missing",
                "the kms profile signs with an operator-held key.",
                "pass --key <ed25519-private-key.pem>.",
            )
        key_file = _require_file(key_path, key="key", what="the signing key")
        loaded = _load_ed25519_private_key(
            key_file,
            bad_algorithm=(
                "sign.key_algorithm",
                "the signing key is not an Ed25519 private key.",
                "supply an Ed25519 key (the algorithm the engine signs with, SPEC §8.7).",
            ),
            unreadable=(
                "sign.key_unreadable",
                "the signing key file could not be parsed as an unencrypted PEM private key.",
                (
                    "supply an unencrypted Ed25519 private key PEM (`openssl genpkey "
                    "-algorithm ed25519 -out key.pem`, or `agentce catalog sign --new-key "
                    "<path>`)."
                ),
            ),
        )
        return signing.KmsSigner(private_key=loaded)
    raise InputError(
        "sign.keyless_offline",
        f"the {profile} profile is keyless and obtains a certificate from a Fulcio instance "
        "(network); the engine does not sign it offline.",
        "use --profile kms --key <file> offline, or run keyless signing where the Fulcio and "
        "Rekor endpoints are reachable.",
    )


def _load_ed25519_private_key(
    key_path: Path,
    *,
    bad_algorithm: tuple[str, str, str],
    unreadable: tuple[str, str, str],
) -> Any:
    """Load and validate an Ed25519 private key PEM at ``key_path`` (SPEC §8.7, §9.1).

    Shared by ``agentce sign``'s ``kms`` profile and ``agentce catalog sign``. An unparseable file or
    a password-protected key with no password supplied (previously an uncaught crash to
    ``internal.unexpected``) raises ``unreadable``; a key that parses but is not Ed25519 raises
    ``bad_algorithm`` (unchanged behaviour, only relocated). A missing ``key_path`` is refused by the
    caller before this helper is ever called (``_require_file`` for ``sign``, the argparse
    mutually-exclusive group for ``catalog sign``), so this helper has no ``missing`` case.
    """
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import load_pem_private_key

    try:
        loaded = load_pem_private_key(key_path.read_bytes(), password=None)
    except (ValueError, TypeError) as exc:
        key, cause, fix = unreadable
        raise InputError(key, cause, fix) from exc
    if not isinstance(loaded, Ed25519PrivateKey):
        key, cause, fix = bad_algorithm
        raise InputError(key, cause, fix)
    return loaded


def _cmd_catalog_sign(ns: argparse.Namespace) -> CommandResult:
    """Sign a catalog directory with an operator-held Ed25519 key (SPEC §8.7, §9.1)."""
    result = CommandResult(command="catalog")
    directory = _require_dir(
        _opt_str(ns, "dir"),
        key="dir",
        what="the catalog directory",
        fix="pass the catalog directory: `agentce catalog sign <dir>`.",
    )
    catalog_dir = directory.resolve()
    if not (directory / "catalog.yaml").is_file():
        raise InputError(
            "catalog.sign_not_a_catalog",
            f"{directory} has no catalog.yaml.",
            "pass a catalog directory, or scaffold one first: `agentce catalog init <dir>`.",
        )
    lint_problems = lint_catalog(directory)
    if lint_problems:
        raise InputError(
            "catalog.sign_lint_failed",
            f"{directory} fails `catalog lint`: {'; '.join(lint_problems)}.",
            "fix the lint problems (`agentce catalog lint <dir>`) before signing.",
        )
    sig_path = directory / signing.CATALOG_SIGNATURE_NAME
    if sig_path.exists() and not _flag(ns, "force"):
        raise InputError(
            "catalog.sign_exists",
            f"{sig_path} already exists.",
            "pass --force to re-sign, or remove the existing signature first.",
        )
    key_arg = _opt_str(ns, "key")
    new_key_arg = _opt_str(ns, "new_key")
    key_arg_raw = new_key_arg if new_key_arg is not None else key_arg
    if key_arg_raw is not None:
        _reject_inside_catalog(
            key_arg_raw,
            catalog_dir,
            key="catalog.sign_key_inside_catalog",
            flag="--new-key" if new_key_arg is not None else "--key",
            noun="key",
            shown_dir=directory,
        )
    write_trust_root = _opt_str(ns, "write_trust_root")
    if write_trust_root is not None:
        _reject_inside_catalog(
            write_trust_root,
            catalog_dir,
            key="catalog.sign_trust_root_inside_catalog",
            flag="--write-trust-root",
            noun="trust root",
            shown_dir=directory,
        )

    new_key_written: str | None = None
    if new_key_arg is not None:
        new_key_path = Path(new_key_arg)
        if new_key_path.exists():
            raise InputError(
                "catalog.sign_new_key_exists",
                f"--new-key {new_key_arg!r} already exists.",
                "pass a path that does not exist yet, or reuse it with --key instead.",
            )
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives.serialization import (
            Encoding,
            NoEncryption,
            PrivateFormat,
        )

        key = Ed25519PrivateKey.generate()
        pem = key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption())
        new_key_path.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(str(new_key_path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            os.write(fd, pem)
        finally:
            os.close(fd)
        new_key_written = str(new_key_path)
    else:
        key_file = _require_file(key_arg, key="key", what="the signing key")
        key = _load_ed25519_private_key(
            key_file,
            bad_algorithm=(
                "catalog.sign_key_algorithm",
                "the signing key is not an Ed25519 private key.",
                "supply an Ed25519 key, or generate one with --new-key.",
            ),
            unreadable=(
                "catalog.sign_key_unreadable",
                "the signing key file could not be parsed as an unencrypted PEM private key.",
                "supply an unencrypted Ed25519 private key PEM, or generate one with --new-key.",
            ),
        )
    signer = signing.KmsSigner(private_key=key)

    catalog_id = catalog_dir.name
    digest = signing.digest_tree(
        directory, exclude=frozenset({signing.CATALOG_SIGNATURE_NAME})
    )
    statement = signing.intoto_statement(
        subject_name=catalog_id,
        digest=digest,
        predicate_type="https://agent-conformance.org/attestation/catalog/v1",
        predicate={"kind": "catalog", "id": catalog_id},
    )
    envelope = signing.sign_statement(statement, signer)
    sig_path.write_text(
        json.dumps(envelope, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    result.data.update(
        {
            "dir": str(directory),
            "signature": str(sig_path),
            "keyid": signer.keyid,
            "catalog_id": catalog_id,
        }
    )
    if new_key_written is not None:
        result.data["new_key"] = new_key_written

    if write_trust_root is not None:
        trust_root_path = Path(write_trust_root)
        trust_root_path.parent.mkdir(parents=True, exist_ok=True)
        trust_root_path.write_text(
            json.dumps(
                signing.TrustRoot.document(
                    signer.keyid,
                    signer.public_key_b64,
                    _opt_str(ns, "identity") or "unset",
                ),
                indent=2,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
        result.data["trust_root"] = str(trust_root_path)
    result.note(
        f"signed {directory}; next: `agentce assess --catalog-dir {directory} --trust-root "
        f"{write_trust_root or '<trust-root.json>'} --bundle ... --profile ...`."
    )
    return result


def _readiness_severities(ns: argparse.Namespace) -> dict[str, str]:
    dirs = list(getattr(ns, "catalog_dir", None) or [])
    if not dirs:
        base = bundled.catalogs_dir() / "base"
        dirs = [str(p.parent) for p in sorted(base.glob("*/catalog.yaml"))]
    severities: dict[str, str] = {}
    for directory in dirs:
        catalog = load_catalog(
            _require_dir(directory, key="catalog-dir", what="a catalog directory")
        )
        for control in catalog.controls:
            severities[control.id] = control.severity
    return severities


def cmd_readiness(ns: argparse.Namespace) -> CommandResult:
    """Compute the report-readiness verdict (SPEC §13.3.4 stage 4). Exit 0 for READY and READY WITH
    LIMITATIONS, 1 for NOT READY; the verdict logic lives in the engine, never in a skill."""
    result = CommandResult(command="readiness")
    report_dir = _require_dir(
        _opt_str(ns, "report_dir"),
        key="report_dir",
        what="the report directory",
        fix="pass the report directory: `agentce readiness <report-dir>`.",
    )
    gaps: set[str] = set()
    gaps_path = _opt_str(ns, "gaps")
    if gaps_path:
        text = _require_file(gaps_path, key="gaps", what="the gaps file").read_text(
            "utf-8"
        )
        gaps = set(re.findall(r"\b[A-Z]{2,4}-[0-9]{2}\b", text))
    deviations: list[dict[str, Any]] = []
    dev_path = _opt_str(ns, "deviations")
    if dev_path:
        deviations = _load_deviation_register(
            _require_file(dev_path, key="deviations", what="the deviation register")
        )
    verdict = readiness.compute_readiness(
        report_dir,
        severities=_readiness_severities(ns),
        deviations=deviations,
        gaps=gaps,
    )
    result.data.update(verdict)
    out = report_dir / f"report-readiness-{date.today().isoformat()}.md"
    lines = [f"# Report readiness — {verdict['verdict']}", ""]
    if verdict["reasons"]:
        lines += ["## Blocking reasons", *[f"- {r}" for r in verdict["reasons"]], ""]
    if verdict["limitations"]:
        lines += [
            "## Limitations",
            *[f"- {limit}" for limit in verdict["limitations"]],
            "",
        ]
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    result.data["report"] = str(out)
    if verdict["verdict"] == readiness.NOT_READY:
        result.add_code(int(ExitCode.FINDINGS))
    return result


def _doctor_problem(key: str, problem: str, fix: str | None = None) -> dict[str, str]:
    entry = MESSAGE_KEYS.get(key)
    return {"key": key, "problem": problem, "fix": fix or (entry.fix if entry else "")}


#: The project layout shared by ``init`` (which writes it), ``doctor`` (which checks it) and the
#: documentation: declarations live in ``<project>/agentce/``.
DECLARATIONS_DIR = "agentce"
PROFILE_FILE = "applicability.yaml"
DOMAIN_FILE = "domain.linkml.yaml"


def _declaration_path(project: Path, name: str) -> Path:
    """Where ``name`` lives in ``project``: ``agentce/<name>``, else the flat layout the vendored
    quickstart project uses (``<name>`` beside the evidence directory)."""
    nested = project / DECLARATIONS_DIR / name
    return (
        nested if nested.is_file() or not (project / name).is_file() else project / name
    )


def cmd_doctor(ns: argparse.Namespace) -> CommandResult:
    """Diagnose the interpreter, toolchain, and a project's declarations, sources, and bundle, naming
    the exact fix for each problem (SPEC §13.4 AX-5). With ``--write-errors`` it regenerates the message-key catalogue instead."""
    result = CommandResult(command="doctor")
    write_errors = _opt_str(ns, "write_errors")
    if write_errors:
        path = Path(write_errors)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(render_errors_md(), encoding="utf-8")
        result.data.update({"errors_md": str(path)})
        result.note(f"wrote {path}")
        return result

    project = _require_dir(
        _opt_str(ns, "project") or DEFAULT_PROJECT_DIR,
        key="project",
        what="the project directory",
        fix="pass --project <dir> (a project from agentce quickstart or agentce init).",
    )
    environment, problems = inspect_environment()
    declared_sources: set[str] = set()

    profile_path = _declaration_path(project, PROFILE_FILE)
    if not profile_path.is_file():
        problems.append(
            _doctor_problem(
                "input.profile_missing",
                f"no {PROFILE_FILE} in {project / DECLARATIONS_DIR} or {project}",
            )
        )
    else:
        from ..tools.validate_profile import validate_profile

        profile_data = yaml.safe_load(profile_path.read_text("utf-8")) or {}
        for problem in validate_profile(profile_data):
            problems.append(
                _doctor_problem(
                    "schema_invalid",
                    problem,
                    "correct the profile to match applicability-profile.schema.json.",
                )
            )
        declared_sources = {
            str(source.get("source"))
            for subject in profile_data.get("subjects", [])
            for source in subject.get("evidence_sources", [])
            if source.get("source")
        }

    bundle_dir = project / "evidence"
    if not bundle_dir.is_dir():
        problems.append(
            _doctor_problem(
                "input.bundle_manifest_missing",
                f"no evidence bundle at {bundle_dir}",
                f"run your agent with the emitter on, `AGENTCE_EMIT=1 AGENTCE_EMIT_OUT={bundle_dir}` "
                "(see docs/integrate.md), or watch one built with "
                f"`examples/custom-loop/run.sh {bundle_dir}` from a checkout; then check it with "
                f"`agentce validate --bundle {bundle_dir}`.",
            )
        )
    else:
        try:
            bundle = load_bundle(bundle_dir)
            manifest_sources = {
                str(source.get("id")) for source in bundle.manifest.get("sources", [])
            }
            for source in sorted(declared_sources - manifest_sources):
                problems.append(
                    _doctor_problem(
                        "unknown_source",
                        f"source {source} is declared but not in the bundle manifest",
                        "add the source's stream and manifest entry, or remove the declaration.",
                    )
                )
        except AgentceError as err:
            problems.append(_doctor_problem(err.key, err.cause, err.fix))

    if not _declaration_path(project, DOMAIN_FILE).is_file():
        problems.append(
            _doctor_problem(
                "input.catalog_not_found",
                f"no domain binding {DOMAIN_FILE} in {project / DECLARATIONS_DIR} or {project}",
                f"add {DECLARATIONS_DIR}/{DOMAIN_FILE} (`agentce init --out {project}` writes a starter).",
            )
        )

    result.data.update(
        {
            "project": str(project),
            "doctor": "ok" if not problems else "problems",
            "healthy": not problems,
            "environment": environment,
            "problems": sorted(problems, key=lambda p: (p["key"], p["problem"])),
        }
    )
    for advice in environment["notes"]:
        result.note(f"[{advice['key']}] {advice['note']} -> {advice['fix']}")
    if problems:
        result.add_code(int(ExitCode.FINDINGS))
        result.note(f"{project}: {len(problems)} problem(s)")
        for issue in problems:
            result.note(f"  [{issue['key']}] {issue['problem']} -> {issue['fix']}")
    else:
        result.note(f"{project}: healthy")
    return result


#: Framework → the evidence-source adapter an adopter most likely starts with (SPEC §12).
_FRAMEWORK_ADAPTER = {
    "langgraph": "otel-genai",
    "openai-agents": "otel-genai",
    "claude-agent-sdk": "otel-genai",
    "google-adk": "otel-genai",
    "crewai": "otel-genai",
    "custom-loop": "agentce-emit",
}
INIT_ROLES = ("deployer", "provider", "both")
#: The identity ``agentce_emit.auto()`` emits under when nothing is configured (its
#: ``DEFAULT_SOURCE``); ``init`` writes the same string (``DEFAULT_SUBJECT``, from ``..records``) so a
#: bare init and a bare ``auto()`` describe one subject and one source. A test holds the two packages equal.
DEFAULT_EMIT_SOURCE = "urn:agentce:emit:local"


def cmd_quickstart(ns: argparse.Namespace) -> CommandResult:
    """Assess the bundled quickstart project end to end — one command, offline (SPEC §13.4 AX-1)."""
    result = CommandResult(command="quickstart")
    out = _opt_str(ns, "out") or DEFAULT_OUT_DIR
    quickstart = bundled.quickstart_dir()
    catalog_dir = bundled.catalogs_dir() / "base" / "eu-ai-act"
    if not quickstart.is_dir():
        raise InputError(
            "input.quickstart_missing",
            f"the quickstart project is missing at {quickstart}.",
            "reinstall the engine: the quickstart project ships inside the package.",
        )
    assess_ns = argparse.Namespace(
        bundle=str(quickstart / "evidence"),
        profile=str(quickstart / "applicability.yaml"),
        domain=str(quickstart / "domain.linkml.yaml"),
        catalog="eu-ai-act@2026.09",
        catalog_dir=[str(catalog_dir)],
        out=out,
        command_name="quickstart",
    )
    assess = cmd_assess(assess_ns)
    result.data.update(assess.data)
    result.data["quickstart"] = "ok"
    for code in assess.codes:
        result.add_code(code)
    for line in _verdict_lines(
        assess_ns,
        assess.data["summary"],
        out,
        report_written="md" in assess.data["emit"],
    ):
        result.note(line)
    result.note(
        f"quickstart complete: {assess.data.get('assertions', 0)} assertions; report in {out}"
    )
    return result


def cmd_init(ns: argparse.Namespace) -> CommandResult:
    """Write a starter applicability profile for an adopter (SPEC §13.4 AX-2)."""
    result = CommandResult(command="init")
    out = _opt_str(ns, "out") or DEFAULT_PROJECT_DIR
    subject = _opt_str(ns, "subject") or DEFAULT_SUBJECT
    role = _opt_str(ns, "role") or "deployer"
    if role not in INIT_ROLES:
        raise InputError(
            "input.init_role",
            f"--role must be one of {', '.join(INIT_ROLES)}.",
            "pass --role deployer|provider|both.",
        )
    framework = _opt_str(ns, "framework") or "custom-loop"
    adapter = _FRAMEWORK_ADAPTER.get(framework, "otel-genai")

    source = (
        DEFAULT_EMIT_SOURCE
        if adapter == "agentce-emit"
        else f"urn:agentce:source:{framework}:TODO"
    )
    profile = _render_starter_profile(
        subject=subject,
        role=role,
        framework=framework,
        adapter=adapter,
        source=source,
    )
    profile_path = Path(out) / DECLARATIONS_DIR / PROFILE_FILE
    domain_path = Path(out) / DECLARATIONS_DIR / DOMAIN_FILE
    existing = [str(p) for p in (profile_path, domain_path) if p.exists()]
    if existing and not _flag(ns, "force"):
        raise InputError(
            "input.init_exists",
            f"init would overwrite {', '.join(existing)}.",
            "pass --force to overwrite, or --out <dir> to write somewhere else.",
        )
    profile_path.parent.mkdir(parents=True, exist_ok=True)
    profile_path.write_text(profile, encoding="utf-8")
    domain_path.write_text(_STARTER_DOMAIN_BINDING, encoding="utf-8")
    result.data.update(
        {
            "out": out,
            "profile": str(profile_path),
            "domain": str(domain_path),
            "framework": framework,
            "subject": subject,
            "source": source,
            "role": role,
        }
    )
    result.note(
        f"wrote a starter profile to {profile_path} and a domain binding to {domain_path}; "
        f"fill in the TODOs, then run `agentce doctor --project {out}`."
    )
    if adapter == "agentce-emit" and (
        subject != DEFAULT_SUBJECT or source != DEFAULT_EMIT_SOURCE
    ):
        result.note(
            f"emit under this subject with AGENTCE_EMIT_SUBJECT={subject} "
            f"AGENTCE_EMIT_SOURCE={source}; without them auto() emits under its own defaults."
        )
    return result


#: An empty binding is valid (SPEC §6.5): no decision type is declared consequential until the
#: adopter names one. The comment shows the shape the graph builder reads.
_STARTER_DOMAIN_BINDING = (
    "# Domain ontology binding generated by `agentce init` (SPEC §6.5). Empty is valid; add the\n"
    "# decision types your agent executes so the graph can flag consequential ones, for example:\n"
    "#\n"
    "# decision_types:\n"
    '#   - id: "dom:CreditDecision"\n'
    '#     subclass_of: "agentce:ConsequentialDecision"\n'
    "#     consequential: true\n"
    '#     required_oversight_modality: "review_before"\n'
    "decision_types: []\n"
    "context_classes: []\n"
)


def _render_starter_profile(
    *, subject: str, role: str, framework: str, adapter: str, source: str
) -> str:
    source_todo = (
        "" if source == DEFAULT_EMIT_SOURCE else "  # TODO: your evidence source id"
    )
    return (
        f"# Starter applicability profile generated by `agentce init` for a {framework} agent "
        "(SPEC §6.5).\n"
        "# Replace every TODO, then assess with `agentce assess --profile this-file ...`.\n"
        "profile_version: 1\n"
        "observation_window:\n"
        '  start: "2026-01-01T00:00:00Z"  # TODO: the start of your assessment window\n'
        '  end: "2026-04-01T00:00:00Z"    # TODO: the end of your assessment window\n'
        "catalogs:\n"
        '  - "eu-ai-act@2026.09"\n'
        "subjects:\n"
        f'  - id: "{subject}"\n'
        f'    role: "{role}"\n'
        "    evidence_sources:\n"
        f'      - adapter: "{adapter}"\n'
        f'        source: "{source}"{source_todo}\n'
        '        class: "self_report"\n'
        '        class_justification: "TODO: justify this source\'s trust class (SPEC §5.2)"\n'
    )


def cmd_config(ns: argparse.Namespace) -> CommandResult:
    """Show the resolved engine configuration and each value's source (SPEC §13.4 AX-8)."""
    result = CommandResult(command="config")
    action = _opt_str(ns, "config_action")
    if action != "show":
        raise InputError(
            "input.config_action",
            "the only config action is `show`.",
            "run `agentce config show`.",
        )
    values = resolve_config()
    result.data["values"] = values
    for entry in values:
        result.note(f"{entry['key']} = {entry['value']}  ({entry['source']})")
    return result


def cmd_version(ns: argparse.Namespace) -> CommandResult:
    result = CommandResult(command="version")
    scan = no_ml.evaluate()
    payload: dict[str, Any] = {
        "engine": ENGINE_NAME,
        "engine_version": __version__,
        "spec_version": SPEC_VERSION,
        "supported_catalogs": [],
        "no_ml": scan["result"],
        "no_ml_detail": scan,
    }
    result.data.update(payload)
    for line in (
        f"{ENGINE_NAME} {__version__} (spec {SPEC_VERSION})",
        f"no_ml: {scan['result']}",
    ):
        result.note(line)
    if scan["result"] != "pass":
        # A learned component is present: an input/environment error for a model-free engine.
        result.add_code(3)
    return result
